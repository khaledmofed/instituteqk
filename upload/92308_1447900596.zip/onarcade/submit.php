{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template submit}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['submit_content']}</h2>
      <div class="content">
        {if strlen($txt['error'])}
        <p class="error">{$txt['error']}</p>
        {/if}
        <form action="{$settings['siteurl']}/submit.php" method="post" name="submit_form" enctype="multipart/form-data">
          <div class="line">
            <p class="label">{$lang['title']}:</p>
            <p><input type="text" name="title" id="title" maxlength="255" value="{$txt['file']['title']}" /></p>
          </div>
          <div class="line">
            <p class="label">{$lang['description']}:</p>
            <p><textarea name="description" id="description">{$txt['file']['description']}</textarea></p>
          </div>
          <div class="line">
            <p class="label">{$lang['category']}</p>
            <p class="right">{$txt['categories']}</p>
          </div>
          <div class="line">
            <p class="label">{$lang['file']}</p>
            <p>
              <input name="upload_file" id="upload_file" type="file" />
              {$lang['max_size_kb']} ({$txt['valid_files']})
            </p>
          </div>
          <div class="line">
            <p class="label">{$lang['image']}</p>
            <p>
              <input name="upload_image" id="upload_image" type="file" />
              {$lang['max_image_size_kb']} ({$txt['valid_images']})
            </p>
          </div>
          {if $settings['image_verification'] == 1}
          <div>
            <p class="bold">{$lang['image_verification']}:</p>
            <div id="image_verification"></div>
          </div>
          <script type="text/javascript"> image_verification.attach("image_verification"); </script>
          {/if}
          <p class="center"><input type="submit" name="submit_file" value="{$lang['submit']}" /></p>
        </form>
      </div>
    </div>
  </div>
  {show menu}
{/template}