{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template browse}
  <div id="main_contents">
  {if is_array($txt['sub'])}
    <div class="content_box">
      <h2>{$lang['subcategories']}</h2>
      <div class="content">
        {foreach $txt['sub'] as $category}
        <p class="subcategory">
          <img src="{$settings['siteurl']}/images/category.png" width="16" height="16" title="{$category['name']}" alt="{$category['name']}" />
          <a href="{$category['url']}">{$category['name']}</a>
        </p>
        {/foreach}
        <div class="clear"></div>
      </div>
    </div>
    {/if}
    <div class="content_box">
      <h2>
        <a href="{$settings['siteurl']}/">{$settings['sitename']}</a>
        {if isset($txt['parent_id'])}
        &gt; <a href="{$txt['parent_url']}">{$txt['parent_title']}</a>
        {/if}
        &gt; {$txt['category_title']}
      </h2>
      <div class="content">
        <div class="pagination">
          {$txt['nav']}
        </div>
        <div class="browse_files"><!--
        {foreach $files as $line => $file}
          --><div class="file">
            <div class="icon">
              <a href="{$file['url']}">
                <img src="{$file['image']}" width="{$settings['image_width']}" height="{$settings['image_height']}" title="{$file['title']}" alt="{$file['title']}" border="0" />
                {if $file['scores'] == 1}
                <span class="scores"></span>
                {/if}
              </a>
            </div>
            <div class="desc">
              <p class="link"><a href="{$file['url']}">{$file['title']}</a></p>
              <div class="stars stars{$file['stars']}" title="{$file['rating']}"></div>
              <p>{$file['description']}</p>
              <p class="played">({$lang['played_times']}: {$file['played']})</p>
            </div>
          </div><!--
          {/foreach}
         --></div>
        <div class="pagination">
          {$txt['nav']}
        </div>
        <div class="txt_right">
          <form name="search" action="{$settings['siteurl']}/search.php" method="post">
            <input type="text" name="t" maxlength="25" size="20" />
            <input type="hidden" name="c" value="{$txt['category_id']}" />
            <input type="submit" value="{$lang['search']}" />
          </form>
          <form name="order" action="" method="post">
            <p>
              {$lang['order_by']}
              <select name="order">
                <option value="title">{$lang['title']}</option>
                <option value="rating" {($order == 'rating' ? 'selected="selected"':'')}>{$lang['rating']}</option>
                <option value="played" {($order == 'played' ? 'selected="selected"':'')}>{$lang['played']}</option>
                <option value="added" {($order == 'added' ? 'selected="selected"':'')}>{$lang['time_added']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
        </div>
      </div>
    </div>
  </div>
  {show menu}
{/template}

{template search}
  <div id="main_contents">
    <div class="content_box">
      <h2><a href="{$settings['siteurl']}/">{$settings['sitename']}</a> &gt; {$txt['search_term']}</h2>
      <div class="content">
        {if empty($files)}
        <p class="error">{$lang['no_results']}</p>
        {else}
        <div class="browse_files"><!--
          {foreach $files as $line => $file}
          --><div class="file">
            <div class="icon">
              <a href="{$file['url']}">
                <img src="{$file['image']}" width="{$settings['image_width']}" height="{$settings['image_height']}" title="{$file['title']}" alt="{$file['title']}" />
                {if $file['scores'] == 1}
                <span class="scores"></span>
                {/if}
              </a>
            </div>
            <div class="desc">
              <p class="link"><a href="{$file['url']}">{$file['title']}</a></p>
              <div class="stars stars{$file['stars']}" title="{$file['rating']}"></div>
              <p>{$file['description']}</p>
              <p class="played">({$lang['played_times']}: {$file['played']})</p>
            </div>
          </div><!--
          {/foreach}
        --></div>
        <div class="arrow_nav">
          {if !empty($txt['previous'])}
          <a href="{$txt['previous']}" class="previous">&lt; {$lang['previous']}</a>
          {/if}
          {if !empty($txt['next'])}
          <a href="{$txt['next']}" class="next">{$lang['next']} &gt;</a>
          {/if}
        </div>
        <div class="txt_right">
          <form name="order" action="{$txt['url']}" method="post">
            <p>
              {$lang['order_by']}
              <select name="order">
                <option value="relevance">{$lang['relevance']}</option>
                <option value="title" {($order == 'title' ? 'selected="selected"':'')}>{$lang['title']}</option>
                <option value="rating" {($order == 'rating' ? 'selected="selected"':'')}>{$lang['rating']}</option>
                <option value="played" {($order == 'played' ? 'selected="selected"':'')}>{$lang['played']}</option>
                <option value="added" {($order == 'added' ? 'selected="selected"':'')}>{$lang['time_added']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
        </div>
        {/if}
      </div>
    </div>
  </div>
  {show menu}
{/template}