{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template member_list}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['search']}</h2>
      <div class="content">
        <form action="memberlist.php" method="post">
          <p>
            {$lang['search']}:
            <input tyle="text" name="n" maxlength="25" value="{$txt['search_tag']}" />
          </p>
          <p>{$lang['list_sort_by']}</p>
          <p><input type="submit" value="{$lang['go']}" /></p>
        </form>
      </div>
    </div>
    <div class="content_box">
      <h2>{$lang['member_list']}</h2>
      <div class="content">
        <div class="members"><!--
          {foreach $txt['members'] as $number => $member}
          --><div class="member">
            <img src="{$member['avatar']}" class="avatar" alt="{$member['name']}" />
            <div class="info">
              <p><a href="{$member['url']}">{$member['name']}</a></p>
              <p>{$lang['played']}: {$member['played']}</p>
              <p>{$lang['comments']}: {$member['comments']}</p>
              <p>{$lang['joined']}: {$member['joined']}</p>
              <p><a href="privatemessages.php?a=compose&amp;u={$member['id']}"><img src="images/send_pm.png" border="0" title="{$lang['pm']}" alt="{$lang['pm']}" /></a></p>
            </div>
          </div><!--
          {/foreach}
        --></div>
        <div class="pagination">
          {$txt['nav']}
        </div>
      </div>
    </div>
  </div>
  {show menu}
{/template}