{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template overall_header}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="shortcut icon" href="{$settings['siteurl']}/favicon.ico" type="image/x-icon" />
<title>{(isset($template->title) ? $template->title .' - '. $settings['sitename'] : $settings['sitename'])}</title>
<link rel="alternate" type="application/rss+xml" title="{$lang['rss_newest_files']} (RSS 2.0)" href="{$settings['siteurl']}/rss.php?r=newest&amp;l=10" />

<meta name="viewport" content="width=device-width" />

<link rel="stylesheet" type="text/css" href="{$settings['siteurl']}/templates/onarcade/style.css" />
<link rel="stylesheet" type="text/css" href="{$settings['siteurl']}/templates/onarcade/mobile.css" />
<meta name="description" content="{$template->description}" />
<meta name="keywords" content="{$template->keywords}" />

<script type="text/javascript">
  var siteurl = "{$settings['siteurl']}/";
  {$template->load_js_lang()}
</script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/jquery.js"></script>
  <script type="text/javascript" src="{$settings['siteurl']}/templates/onarcade/template.js"></script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/global.js"></script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/swfobject.js"></script>
{$template->header}
</head>

{/template}

{template header}
<body>

{if $cookies_message}
<div id="cookies_message">
  {$lang['cookies_message']}
  <a href="" class="close"><img src="{$settings['siteurl']}/images/close.png" title="{$lang['close']}" alt="{$lang['close']}" /></a>
</div>
<script type="text/javascript"> cookies_message.init(); </script>
{/if}
<div id="header">
  <div id="mobile_menu">
	<a href="" id="member_menu_switch"></a>
	<a href="" id="categories_menu_switch"></a>
  </div>
  <a href="{$settings['siteurl']}/" id="home"><h1>{$settings['sitename']}</h1></a>

  <script type="text/javascript"> mobileMenu.init(); </script>
  {if $settings['memberlogin'] == 1}
  <div id="member_menu">
    {if $session->info['status'] == 1}
	<ul>
      {if $session->user_group == 2}
      <li><a href="{$settings['siteurl']}/admin/index.php">{$lang['admin_cp']}</a></li>
      {/if}
      <li><a href="{$settings['siteurl']}/usercp.php">{$lang['user_cp']}</a></li>
      <li><a href="{$settings['siteurl']}/privatemessages.php">{$lang['private_messages']} (<span class="{($session->unread > 0 ? 'unread':'no_unread')}">{$session->unread}</span>)</a></li>
      <li><a href="{$settings['siteurl']}/usercp.php" id="notifications">{$lang['notifications']} (<span class="{($session->notifications > 0 ? 'unread':'no_unread')}">{$session->notifications}</span>)</a></li>
      <li><a href="{$settings['siteurl']}/usercp.php?a=favorites" id="favourites_link">{$lang['favourites']} <img src="{$settings['siteurl']}/images/menu.png" alt="" width="10" height="10" /></a></li>
      {if $settings['forums'] == 1}
      <li><a href="{$settings['siteurl']}/forums.php">{$lang['forums']}</a></li>
      {/if}
      <li><a href="{$settings['siteurl']}/login.php?a=logout">{$lang['logout']}</a></li>
	</ul>
    {else}
    <form action="{$settings['siteurl']}/login.php" method="post">
      {$lang['username']}
      <input type="text" name="username" maxlength="25" />
      {$lang['password']}
      <input type="password" name="password" />
      <input type="hidden" name="remember" value="1" />
      <input type="submit" name="submit" value="{$lang['log_in']}" class="button" />
      <a href="{$settings['siteurl']}/profile.php?a=register" class="button">{$lang['register']}</a>
    </form>
    {/if}
  </div>
  {/if}
  <ul id="categories">
  {foreach $menu->categories as $category}
    <li{($category['first']?' class="first"':'')}><a href="{$category['url']}">{$category['title']}</a></li>
  {/foreach}
  </ul>
</div>
<div id="main">
  {show header_ad}
      {if $settings['guestcredits'] == 1 && $session->info['status'] != 1}
  <div class="content_box_2 center">
	  <div class="content"><a href="{$settings['siteurl']}/profile.php?a=register">{$lang['more_plays_left']}</a></div>
  </div>
      {/if}
{/template}

{template footer}
  <div class="clear"></div>
  {show footer_ad}
</div>
<div id="footer">
  <ul id="footer_menu">
    <li class="first"><a href="{$settings['siteurl']}/">{$lang['home']}</a></li>
    {if $settings['cups'] == 1}
    <li><a href="{$settings['siteurl']}/cup.php?a=all">{$lang['cups']}</a></li>
    {/if}
    {if $settings['memberlogin'] == 1}
    <li><a href="{$settings['siteurl']}/memberlist.php">{$lang['member_list']}</a></li>
    {/if}
    {if $settings['links'] == 1}
    <li><a href="{$settings['siteurl']}/links.php">{$lang['links']}</a></li>
    {/if}
    {if $settings['submit'] == 1 || $session->user_status == 1 && $settings['submit'] == 2}
    <li><a href="{$settings['siteurl']}/submit.php">{$lang['submit_content']}</a></li>
    {/if}
    {if !empty($settings['privacy_policy_url'])}
    <li><a href="{$settings['privacy_policy_url']}">{$lang['privacy_policy']}</a></li>
    {/if}
    <li><a href="{$settings['siteurl']}/contact.php">{$lang['contact_us']}</a></li>
  </ul>
  <p>{$lang['footer_copyright']}</p>
  <p>
    <!-- onArcade 2.4 -->
    Powered by <a href="http://www.onarcade.com">onArcade</a>
  </p>
</div>

</body>

</html>
{/template}

{template menu}
  <div id="side_menu">
    <div class="content_box_2">
      <h3>{$lang['statistics']}</h3>
      <div class="content">
        <p>{$lang['total_files']}: {$statistics->f('files')}</p>
        <p>{$lang['played_today']}: {$statistics->f('played_today')}</p>
        <p>{$lang['overall_played']}: {$statistics->f('total_played')}</p>
        {if $settings['memberlogin'] == 1}
        <p>{$lang['total_members']}: {$statistics->f('members')}</p>
        {/if}
        <p>
          {$lang['users_online']}: {$statistics->f('online')}
        {if $settings['memberlogin'] == 1}
          ({$statistics->f('members_online')} {($statistics->members_online == 1 ? $lang['member_online'] : $lang['members_online'])},
          {$statistics->f('guests_online')} {($statistics->guests_online == 1 ? $lang['guest_online'] : $lang['guests_online'])})
          {if !empty($statistics->online_list)}
          <br />{$lang['members_online_list']} {$statistics->online_list}
          {/if}
        {/if}
        </p>
      </div>
    </div>
    {if $settings['most_popular_list'] == 1}
    <div class="content_box_2">
      <h3>{$lang['most_popular']}</h3>
      <div class="content">
        <ol>
          {foreach $menu->most_popular AS $popular}
          <li><a href="{$popular['url']}">{$popular['title']}</a> ({$popular['played']} {$lang['most_popular_times']})</li>
          {/foreach}
        </ol>
      </div>
    </div>
    {/if}
    {if $settings['newest_list'] == 1}
    <div class="content_box_2">
      <h3>{$lang['newest']}</h3>
      <div class="content">
        <ol>
          {foreach $menu->newest AS $new}
          <li><a href="{$new['url']}">{$new['title']}</a> ({$new['played']} {$lang['most_popular_times']})</li>
          {/foreach}
        </ol>
      </div>
    </div>
    {/if}
    {if $settings['top_players_list'] != 0 && $settings['memberlogin'] == 1}
    <div class="content_box_2">
      <h3>{$lang['top_players']}</h3>
      <div class="content">
        <ol>
          {foreach $menu->top_players AS $players}
          <li><a href="{$players['url']}">{$players['username']}</a> ({$players['number']} {($settings['top_players_list'] == 2 ? $lang['top_wins'] : $lang['top_plays'])})</li>
          {/foreach}
        </ol>
      </div>
    </div>
    {/if}
    <div class="content_box_2">
      <h3>{$lang['search']}</h3>
      <div class="content">
        <form action="{$settings['siteurl']}/search.php" method="post">
          <p><input type="text" name="t" maxlength="25" /></p>
          <p><input type="submit" value="{$lang['search']}" /></p>
        </form>
        {if $settings['tag_cloud'] == 1}
        <div class="center">
          {foreach $menu->tags AS $tag}
          <a href="{$tag['url']}" style="font-size:{$tag['size']}px">{$tag['tag']}</a>
          {/foreach}
        </div>
        {/if}
      </div>
    </div>
    {if $settings['links'] == 1}
    <div class="content_box_2">
      <h3>{$lang['links']}</h3>
      <div class="content">
        {foreach $menu->links as $link}
        <p><a href="{$link['url']}" onclick="return link_out({$link['id']});">{$link['name']}</a></p>
        {/foreach}
        <p>
          <a href="{$settings['siteurl']}/links.php" class="button">{$lang['more_links']}</a>
        </p>
      </div>
    </div>
    {/if}
    <div class="center">
      <a href="{$settings['siteurl']}/rss.php"><img src="{$settings['siteurl']}/images/rss_feed.png" width="32" height="32" title="{$lang['rss_feed']}" alt="{$lang['rss_feed']}" /></a>
    </div>
  </div>
{/template}

{template index}
  <div id="main_contents">
    <div class="content_box_2">
      <h3>{$lang['welcome_to']}</h3>
      <div class="content"><p>{$lang['index_box_text']}</p></div>
    </div>
    {if $settings['news'] != 0}
    <div class="content_box_2">
      <h3>{$lang['news']}</h3>
      <div class="content">
        {foreach news() as $news}
        <div class="news_box">
          <p><span class="bold">{$news['title']}</span> ({$news['date']})</p>
          <p>{$news['text']}</p>
        </div>
		<div class="separator"></div>
        {/foreach}
        {if $settings['news'] == 2}
        <p class="center"><a href="{$settings['siteurl']}/forums.php?a=forum&amp;f={$settings['news_forum']}" class="button">{$lang['more_news']}</a></p>
        {/if}
      </div>
    </div>
    {/if}
    {if $settings['champions'] == 1}
    <div class="content_box_2">
      <h3>{$lang['champions']}</h3>
      <div class="content">
        {if isset($champions['first'])}
        <div class="champion">
          <div class="medals medals_first"></div>
          <a href="{$champions['first']['url']}" class="bold">{$champions['first']['username']}</a><br />
          {$champions['first']['wins']} {$lang['top_wins']}
        </div>
        {/if}
        {if isset($champions['second'])}
        <div class="champion">
          <div class="medals medals_second"></div>
          <a href="{$champions['second']['url']}" class="bold">{$champions['second']['username']}</a><br />
          {$champions['second']['wins']} {$lang['top_wins']}
        </div>
        {/if}
        {if isset($champions['third'])}
        <div class="champion">
          <div class="medals medals_third"></div>
          <a href="{$champions['third']['url']}" class="bold">{$champions['third']['username']}</a><br />
          {$champions['third']['wins']} {$lang['top_wins']}
        </div>
        {/if}
        <div class="clear"></div>
        <p class="center">
          <a href="scores.php?a=champions" class="button">{$lang['all_champions']}</a>
        </p>
        <h4>{$lang['latest_scores']}</h4>
        {foreach $champions['latest'] as $latest}
        <p class="latest_line"><span>{$latest['date']}</span>{$latest['message']}</p>
        {/foreach}
        {if $settings['cups'] == 1}
        <h4>{$lang['live_cups']}</h4>
        {if !empty($cups)}
        {foreach $cups as $cup}
        <p class="cup">
          <span class="end_time">{$lang['closing']}: {$cup['time_end']}</span>
          <span class="games">{$cup['games']}</span>
          <a href="{$settings['siteurl']}/cup.php?id={$cup['cup_id']}">{$cup['name']}</a>
        </p>
        {/foreach}
        {else}
        <p>{$lang['no_cups']}</p>
        {/if}
        <p class="center">
          <a href="cup.php?a=all" class="button">{$lang['all_cups']}</a>
        </p>
        {/if}
      </div>
    </div>
    {/if}
    {if $settings['scroller'] == 1}
    <div id="scroller"><h4>{$lang['scroller_title']}</h4></div>
    <script type="text/javascript">
      scroller.files = {$main['scroller']};
      scroller.init({$settings['image_width']}, {$settings['image_height']});
    </script>
    {/if}
	  <div class="index_files_columns_container"><!--
    {foreach $main['categories'] as $var => $category}
      --><div class="content_box index_files_column">
        <h2>{$category['title']}</h2>
        <div class="content">
          {foreach $main['files'][$category['id']] as $file}
          <div class="file file_index">
            <div class="icon">
              <a href="{$file['url']}">
                <img src="{$file['image']}" width="{$settings['image_width']}" height="{$settings['image_height']}" alt="{$file['title']}" />
                {if $file['scores'] == 1}
                <span class="scores"></span>
                {/if}
              </a>
            </div>
            <div class="desc">
              <p class="link"><a href="{$file['url']}">{$file['title']}</a></p>
              <div class="stars stars{$file['stars']}" title="{$file['rating']}"></div>
              <p>{$file['description']}</p>
              <p class="played">({$lang['played_times']}: {$file['played']})</p>
            </div>
          </div>
          {/foreach}
          <p class="center">
            <a href="{$category['url']}" class="button">{$lang['more_in_category']} {$category['title']}</a>
          </p>
        </div>
    </div><!--
    {/foreach}
    --></div>
  </div>
  {show menu}
{/template}

{template rss_feeds}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['rss_feed']}</h2>
      <div class="content">
        <p>{$lang['rss_feed_introduction']}</p>
        <p>- <a href="{$settings['siteurl']}/rss.php?r=mostpopular&amp;l=10">{$lang['rss_most_popular_files']}</a></p>
        <p>- <a href="{$settings['siteurl']}/rss.php?r=newest&amp;l=10">{$lang['rss_newest_files']}</a></p>
        <p>- <a href="{$settings['siteurl']}/rss.php?r=news&amp;l=10">{$lang['rss_news']}</a></p>
        {foreach $categories as $category}
        <p>- <a href="{$settings['siteurl']}/rss.php?r=category&amp;id={$category['id']}&amp;l=10">{$category['name']}</a></p>
        {/foreach}
      </div>
    </div>
  </div>
  {show menu}
{/template}

{template redirect($redirect_url, $redirect_message)}
  {show overall_header}
<div id="redirection_box">
  <p>{$redirect_message}</p>
  <p>{$lang['if_not_redirected']}</p>
  <script type="text/javascript">
  setTimeout("window.location = '{$redirect_url}';", 1000);
  </script>
</div>
</body>
</html>
{/template}

{template header_ad}
  {if $settings['header_ad'] == 1}
  <div class="ad_box">
    {$ads->header}
  </div>
  {/if}
{/template}

{template footer_ad}
  {if $settings['footer_ad'] == 1}
  <div class="ad_box">
    {$ads->footer}
  </div>
  {/if}
{/template}

{template blank_page($title,$content)}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$title}</h2>
      <div class="content">{$content}</div>
    </div>
  </div>
  {show menu}
{/template}