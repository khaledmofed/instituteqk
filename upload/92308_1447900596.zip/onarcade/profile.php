{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template profile}
  {show profile_menu}
  <div id="profile_contents">
    <div class="content_box">
      <h2>{$lang['profile']}</h2>
      <div class="content">
        <div class="line">
          <p class="label">{$lang['name']}:</p>
          <p>{$profile['name']}</p>
        </div>
        <div class="line">
          <p class="label">{$lang['gender']}:</p>
          <p>{$profile['gender']}</p>
        </div>
        {if !empty($profile['age'])}
        <div class="line">
          <p class="label">{$lang['age']}:</p>
          <p>{$profile['age']}</p>
        </div>
        {/if}
        <div class="line">
          <p class="label">{$lang['location']}:</p>
          <p id="user_location">
            <span>{$profile['location']}</span>
            <img src="{$settings['siteurl']}/images/globe.png" alt="" />
          </p>
        </div>
        <div class="line">
          <p class="label">{$lang['joined']}:</p>
          <p>{$profile['date_joined']}</p>
        </div>
        <div class="line">
          <p class="label">{$lang['last_visit']}:</p>
          <p>{$profile['last_visit']}</p>
        </div>
        <div class="line">
          <p class="label">{$lang['played']}:</p>
          <p>{$profile['played']}</p>
        </div>
        {if $profile['top_scores'] > 0}
        <div class="line">
          <p class="label">{$lang['top_scores']}:</p>
          <p>{$profile['top_scores']}</p>
        </div>
        {/if}
        <div class="line">
          <p class="label">{$lang['comments']}:</p>
          <p>{$profile['comments']}</p>
        </div>
        {if $settings['forums'] == 1}
        <div class="line">
          <p class="label">{$lang['forum_posts']}:</p>
          <p>{$profile['forum_posts']}</p>
        </div>
        {/if}
        {if strlen($profile['website']) > 0}
        <div class="line">
          <p class="label">{$lang['website']}:</p>
          <p><a href="{$profile['website']}" target="_blank">{$profile['website']}</a></p>
        </div>
        {/if}
        {if $profile['see_messengers']}
        <div class="info_column">
          <div class="line">
            <p class="label">{$lang['msn']}:</p>
            <p>{$profile['msn']}</p>
          </div>
          <div class="line">
            <p class="label">{$lang['aim']}:</p>
            <p>{$profile['aim']}</p>
          </div>
          <div class="line">
            <p class="label">{$lang['skype']}:</p>
            <p>{$profile['skype']}</p>
          </div>
        </div>
        <div class="info_column">
          <div class="line">
            <p class="label">{$lang['yahoo']}:</p>
            <p>{$profile['yahoo']}</p>
          </div>
          <div class="line">
            <p class="label">{$lang['icq']}:</p>
            <p>{$profile['icq']}</p>
          </div>
          <div class="line">
            <p class="label">{$lang['google_talk']}:</p>
            <p>{$profile['google_talk']}</p>
          </div>
        </div>
        <div class="clear"></div>
        {/if}
      </div>
    </div>
    {if !empty($favorites['files'])}
    <div class="content_box">
      <h2>{$lang['favourites']}</h2>
      <div class="content" id="favorites">
        {show favorites}
      </div>
    </div>
    {/if}
    {if !empty($friends)}
    <div class="content_box">
      <h2>{$lang['friends']}</h2>
      <div class="content" id="friends">
        {show friends}
      </div>
    </div>
    {/if}
    {if !empty($scores['files'])}
    <div class="content_box">
      <h2>{$lang['high_scores']}</h2>
      <div class="content" id="high_scores">
        {show high_scores}
      </div>
    </div>
    {/if}
    {if $settings['profile_comments'] == 1}
    <div class="content_box">
      <h2>{$lang['profile_comments']}</h2>
      <div class="content">
        {if $session->user_status == 1}
        <form action="" method="post" id="comment_form">
          <div id="bb_code"></div>
          <p><textarea name="message" id="message" class="comment"></textarea></p>
          <p><input type="submit" value="{$lang['submit']}" /></p>
        </form>
        <script type="text/javascript">
          bb_code.attach_emoticons("bb_code", "message");
        </script>
        <div class="separator"></div>
        {/if}
        <div id="comments"></div>
        <script type="text/javascript">
          profile.comments = {$comments};
        </script>
      </div>
    </div>
    {/if}
    <script type="text/javascript">
      profile.init({$profile['id']});
    </script>
  </div>
{/template}

{template favorites}
        {foreach $favorites['files'] AS $file}
        <div class="file">
          <a href="{$file['url']}">
            <img src="{$file['image']}" width="{$settings['image_width']}" height="{$settings['image_height']}" title="{$file['title']}" alt="{$file['title']}" />
            {$file['title']}
          </a>
        </div>
        {/foreach}
        <div class="clear"></div>
        {if $favorites['more']}
        <a href="" id="more_favorites" class="load_more">{$lang['load_more']}</a>
        {/if}
{/template}

{template high_scores}
        {foreach $scores['files'] as $file}
        <div class="file">
          <a href="{$file['url']}"><img src="{$file['image']}" width="{$settings['image_width']}" height="{$settings['image_height']}" title="{$file['title']}" alt="{$file['title']}" /></a>
          {$lang['score']}: {$file['score']}
        </div>
        {/foreach}
        <div class="clear"></div>
        {if $scores['more']}
        <a href="" id="more_high_scores" class="load_more">{$lang['load_more']}</a>
        {/if}
{/template}

{template friends}
        {foreach $friends['users'] AS $user}
        <div class="friend">
          <a href="{$user['url']}">
            <img src="{$user['avatar']}" alt="" />
            {$user['username']}
          </a>
        </div>
        {/foreach}
        <div class="clear"></div>
        {if $friends['more']}
        <a href="" id="more_friends" class="load_more">{$lang['load_more']}</a>
        {/if}
{/template}

{template profile_menu}
  <div id="profile_menu">
    <div class="content_box_2">
      <h3>{$lang['profile']}</h3>
      <div class="content">
        <p><img src="{$profile['avatar']}" alt="{$profile['username']}" title="{$profile['username']}" /></p>
        {if strlen($profile['quote']) > 0}
        <p class="italic">&quot;{$profile['quote']}&quot;</p>
        {/if}
        <p><a href="{$profile['url']}" class="username">{$profile['username']} {$profile['online']}</a></p>
        {if $profile['group'] == 2}
        <p>{$lang['administrator']}</p>
        {/if}
        <p><a href="{$settings['siteurl']}/privatemessages.php?a=compose&amp;u={$profile['id']}" class="button">{$lang['send_pm']}</a></p>
        {if $profile['id'] == $session->user_id}
        <p><a href="{$settings['siteurl']}/usercp.php" class="button">{$lang['user_cp']}</a></p>
        {elseif $session->user_status == 1 && !$profile['is_friend']}
        <p><a href="" id="friend_request" class="button">{$lang['be_friend']}</a></p>
        {/if}
      </div>
    </div>
  </div>
{/template}

{template register}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['register']}</h2>
      <div class="content">
        {if isset($txt['error'])}
        <p class="error">{$txt['error']}</p>
        {/if}
        <form action="" method="post" id="reg_form">
          <fieldset>
            <legend>{$lang['username']}</legend>
            <p><input type="text" name="username" maxlength="25" value="{$txt['register']['username']}" /></p>
          </fieldset>
          <fieldset>
            <legend>{$lang['password']}</legend>
            <div class="register_info">
              <p>{$lang['password']}:</p>
              <p><input type="password" name="password" maxlength="50" /></p>
            </div>
            <div class="register_info">
              <p>{$lang['confirm_password']}:</p>
              <p><input type="password" name="password_2" maxlength="50" /></p>
            </div>
            <div class="clear"></div>
          </fieldset>
          <fieldset>
            <legend>{$lang['email']}</legend>
            <div class="register_info">
              <p>{$lang['email']}:</p>
              <p><input type="text" name="email" maxlength="50" value="{$txt['register']['email']}" /></p>
            </div>
            <div class="register_info">
              <p>{$lang['confirm_email']}:</p>
              <p><input type="text" name="email_2" maxlength="50" value="{$txt['register']['email_2']}" /></p>
            </div>
            <div class="clear"></div>
          </fieldset>
          {if $settings['image_verification'] == 1}
          <fieldset>
            <legend>{$lang['image_verification']}</legend>
            <div id="image_verification"></div>
          </fieldset>
          {/if}
          <fieldset>
            <legend>{$lang['terms']}</legend>
            <div>
              {$lang['terms_text']}
            </div>
            <p class="bold">
              <label><input type="checkbox" name="agree" value="1"{$txt['register']['agree']} /> {$lang['i_agree']}</label>
            </p>
          </fieldset>
          <p class="center"><input type="submit" value="{$lang['register']}" /></p>
        </form>
        <script type="text/javascript">
          register.init();
        </script>
      </div>
    </div>
  </div>
  {show menu}
{/template}