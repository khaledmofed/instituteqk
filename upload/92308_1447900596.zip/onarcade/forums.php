{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template forums}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['forums']}</h2>
      <div class="content">
        <div class="table forums">
          {foreach $txt['categories'] as $categories}
          <div>
            <div class="forums_category">{$categories['cat_title']}</div>
          </div>
          {foreach $txt['forums'][$categories['cat_id']] as $forums}
          <div>
            <div class="status_image">
              {if $forums['new']}
              <img src="images/forum_new.png" class="forum_icon" title="{$lang['new']}" alt="{$lang['new']}" />
              {else}
              <img src="images/forum_read.png" class="forum_icon" title="{$lang['read']}" alt="{$lang['read']}" />
              {/if}
            </div>
            <div class="last_reply">{$lang['last_reply']}: {$forums['last_reply']}</div>
            <div class="stats">
              <p>{$lang['topics']}: {$forums['topics']}</p>
              <p>{$lang['replies']}: {$forums['replies']}</p>
            </div>
            <div class="title">
              <p><a href="forums.php?a=forum&amp;f={$forums['forum_id']}">{$forums['title']}</a></p>
              <p>{$forums['description']}</p>
            </div>
          </div>
          {/foreach}
          {/foreach}
        </div>
      </div>
    </div>
  </div>
  {show menu}
{/template}

{template forum}
  <div id="main_contents">
    <div class="content_box">
      <h2><a href="forums.php">{$lang['forums']}</a> &gt; {$txt['forum']['title']}</h2>
      <div class="content">
        <div class="pagination forums_pagination">
          {$txt['navigation']}
        </div>
        {if $txt['forum']['permission']}
        <p><a href="forums.php?a=new_topic&amp;f={$txt['forum']['forum_id']}" class="button">{$lang['new_topic']}</a></p>
        {/if}
        <div class="clear"></div>
        <div class="table forums">
          {if empty($txt['topics'])}
          <p class="center">{$lang['no_posts']}</p>
          {else}
          {foreach $txt['topics'] as $topics}
          <div>
            <div class="status_image_s">
              {if $topics['status'] == 1}
              <img src="images/topic_new.png" class="post_icon" alt="{$lang['new']}" title="{$lang['new']}" />
              {elseif $topics['status'] == 2}
              <img src="images/locked.png" class="post_icon" alt="{$lang['locked']}" title="{$lang['locked']}" />
              {else}
              <img src="images/topic.png" class="post_icon" alt="" />
              {/if}
            </div>
            <div class="last_reply">
              <p>{$lang['last_reply']}: {$topics['last_reply']}</p>
            </div>
            <div class="stats">
              <p>{$lang['replies']}: {$topics['replies']}</p>
              <p>{$lang['views']}: {$topics['views']}</p>
            </div>
            <div class="title">
              <p>
                {if $topics['sticky'] == 1}
                {$lang['sticky']}:
                {/if}
                <a href="forums.php?a=topic&amp;t={$topics['topic_id']}">{$topics['title']}</a>
              </p>
            </div>
          </div>
          {/foreach}
          {/if}
        </div>
        <div class="pagination forums_pagination">
          {$txt['navigation']}
        </div>
        {if $txt['forum']['permission']}
        <p><a href="forums.php?a=new_topic&amp;f={$txt['forum']['forum_id']}" class="button">{$lang['new_topic']}</a></p>
        {/if}
        <div class="clear"></div>
        <div class="forums_help_info">
          <p><img src="images/topic.png" width="16" height="16" alt="{$lang['read']}" /> - {$lang['read']}</p>
          <p><img src="images/topic_new.png" width="16" height="16" alt="{$lang['new']}" /> - {$lang['new']}</p>
          <p><img src="images/locked.png" width="16" height="16" alt="{$lang['locked']}" /> - {$lang['locked']}</p>
        </div>
      </div>
    </div>
  </div>
  {show menu}
{/template}

{template topic}
  <div id="main_contents">
    <div class="content_box">
      <h2>
        <a href="forums.php">{$lang['forums']}</a> &gt;
        <a href="forums.php?a=forum&amp;f={$txt['topic']['forum_id']}">{$txt['topic']['forum_title']}</a> &gt;
        {$txt['topic']['topic_title']}
      </h2>
      <div class="content">
        <div class="pagination forums_pagination">
          {$txt['navigation']}
        </div>
        {if $txt['topic']['permission']}
        <p>
          <a href="forums.php?a=new_reply&amp;t={$txt['topic']['topic_id']}" class="button">{$lang['reply']}</a>
        </p>
        {/if}
        <div class="clear"></div>
        {foreach $txt['replies'] as $reply}
        <div class="post forum_post">
           <div class="poster">
            <p class="avatar"><img src="{$reply['avatar']}" alt="" /></p>
            <p class="user">{$reply['username']}</p>
            <div class="details">
              <p>{$lang['played']}: {$reply['user_played']}</p>
              <p>{$lang['comments']}: {$reply['user_comments']}</p>
              <p>{$lang['joined']}: {$reply['user_joined']}</p>
              {if $session->user_group == 2}
              <p>({$reply['poster_ip']})</p>
              {/if}
            </div>
          </div>
          <div class="contents">
            <div class="header">
              <p>
                <img src="images/message.png" width="10" height="10" alt="" />
                {$reply['title']}
                <span>- {$reply['date_posted']}</span>
              </p>
            </div>
            <div class="message">{$reply['message']}</div>
            <div class="footer">
              <p>
                {if $reply['poster_id'] == $session->user_id || $session->user_group == 2}
                <a href="forums.php?a=edit_post&amp;r={$reply['reply_id']}" class="button">{$lang['edit']}</a>
                <a href="forums.php?a=delete&amp;r={$reply['reply_id']}" onclick="return confirm_delete();" class="button">{$lang['delete']}</a>
                {/if}
                {if $txt['topic']['permission']}
                <a href="forums.php?a=new_reply&amp;r={$reply['reply_id']}" class="button">{$lang['reply']}</a>
                {/if}
              </p>
            </div>
          </div>

        </div>
        {/foreach}
        <div class="pagination forums_pagination">
          {$txt['navigation']}
        </div>
        {if $txt['topic']['permission']}
        <p><a href="forums.php?a=new_reply&amp;t={$txt['topic']['topic_id']}" class="button">{$lang['reply']}</a></p>
        {/if}
        <div class="clear"></div>
        {if $session->user_group == 2}
        <div class="forums_help_info">
          <form action="" method="post">
            <select name="moderate_action">
              <option value="lock">{$lang['lock']}</option>
              <option value="sticky">{$lang['sticky_not']}</option>
              <option value="delete">{$lang['delete']}</option>
            </select>
            <input type="submit" value="{$lang['submit']}" name="submit_moderate" />
          </form>
        </div>
        {/if}
      </div>
    </div>
  </div>
  {show menu}
{/template}

{template post}
  <div id="main_contents">
    <div class="content_box">
      <h2><a href="forums.php">{$lang['forums']}</a> &gt; {$txt['post_title']}</h2>
      <div class="content">
        <form method="post" action="">
          {if isset($txt['preview'])}
          <div class="post forum_post">
            <div class="poster">
              <p class="avatar"><img src="{$txt['avatar']}" alt="" /></p>
              <p class="user">{$txt['username']}</p>
              <div class="details">
                <p>{$lang['played']}: {$txt['played']}</p>
                <p>{$lang['comments']}: {$txt['comments']}</p>
              </div>
            </div>
            <div class="contents">
              <div class="header">
                <p>
                  <img src="images/message.png" width="10" height="10" alt="" />
                  {$txt['preview']['title']}
                </p>
              </div>
              <div class="message">{$txt['preview']['message']}</div>
            </div>
          </div>
          {/if}
          {if isset($txt['error'])}
          <p class="error">{$txt['error']}</p>
          {/if}
          <div class="line">
            <p class="label">{$lang['title']}:</p>
            <p><input type="text" name="title" maxlength="200" value="{$txt['message']['title']}" /></p>
          </div>
          <div class="line">
            <p class="label">{$lang['message']}:</p>
            <div>
              <div id="bb_code"></div>
              <p><textarea name="message" id="message" class="message">{$txt['message']['message']}</textarea></p>
            </div>
          </div>
          <div class="center">
            <input type="submit" name="submit_post" value="{$lang['submit']}" />
            <input type="submit" name="preview_post" value="{$lang['preview']}" />
          </div>
        </form>
        <script type="text/javascript">
          bb_code.attach("bb_code", "message");
        </script>
      </div>
    </div>
    {if isset($txt['recent'])}
    <div class="content_box">
      <h2>{$lang['latest_responses']}</h2>
      <div class="content">
        {foreach $txt['recent'] AS $recent}
        <div class="post forum_post">
          <div class="poster">
            <p class="user">{$recent['username']}</p>
          </div>
          <div class="content">
            <div class="header">
              <p>
                <img src="images/message.png" width="10" height="10" border="0" alt="" />
                {$recent['title']}
                <span>- {$recent['date_posted']}</span>
              </p>
            </div>
            <div class="message">{$recent['message']}</div>
          </div>
        </div>
        {/foreach}
      </div>
    </div>
    {/if}
  </div>
  {show menu}
{/template}