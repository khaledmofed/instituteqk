{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template sponsor}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['sponsor']}</h2>
      <div class="content">
        <p>{$lang['sponsor_text']}</p>
        <form action="{(PAYPAL_URL)}" method="post">
          <input type="hidden" name="cmd" value="_xclick" />
          <input type="hidden" name="business" value="{$settings['paypal_email']}" />
          <input type="hidden" name="item_name" value="{$lang['sponsor']}" />
          <div class="line">
            <p class="label">{$lang['file']}</p>
            <p>{$txt['files']}</p>
          </div>
          <input type="hidden" name="amount" value="{$settings['sponsor_price']}" />
          <input type="hidden" name="no_shipping" value="1" />
          <input type="hidden" name="return" value="{$settings['siteurl']}/" />
          <input type="hidden" name="notify_url" value="{$settings['siteurl']}/sponsor.php?a=callback" />
          <input type="hidden" name="no_note" value="1" />
          <input type="hidden" name="currency_code" value="USD" />
          <input type="hidden" name="lc" value="US" />
          <input type="hidden" name="bn" value="PP-BuyNowBF" />
          <div class="line">
            <p class="label">{$lang['price']}</p>
            <p>${$settings['sponsor_price']}</p>
          </div>
          <div class="line">
            <p class="label"><input type="hidden" name="on0" value="Link text" />{$lang['link_text']}</p>
            <p><input type="text" name="os0" id="os0" maxlength="60" /></p>
          </div>
          <div class="line">
            <p class="label"><input type="hidden" name="on1" value="URL" />{$lang['url']}:</p>
            <p><input type="text" name="os1" id="os1" maxlength="100" value="http://" /></p>
          </div>
          <p class="center"><input type="image" src="https://www.paypal.com/en_US/i/btn/x-click-but01.gif" border="0" name="submit" alt="Make payments with PayPal - it's fast, free and secure!" /></p>
        </form>
      </div>
    </div>
  </div>
  {show menu}
{/template}