{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template login}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['log_in']}</h2>
      <div class="content">
        {if $txt['error']}
        <p class="error">{$txt['error']}</p>
        {/end}
        <form action="" method="post">
          <div class="line">
            <p class="label">{$lang['username']}:</p>
            <p><input type="text" name="username" maxlength="25" size="20" /></p>
          </div>
          <div class="line">
            <p class="label">{$lang['password']}:</p>
            <p><input type="password" name="password" maxlength="20" size="20" /></p>
          </div>
          <div class="line">
            <p class="label"><label for="remember">{$lang['remember']}:</label></p>
            <p><input type="checkbox" name="remember" id="remember" value="1" checked="checked" /></p>
          </div>
          <p><input type="submit" name="submit" value="{$lang['log_in']}" /></p>
          <p><a href="{$settings['siteurl']}/login.php?a=lost_password">{$lang['forgot_password']}</a></p>
        </form>
      </div>
    </div>
  </div>
  {show menu}
{/template}

{template lost_password}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['lost_password_recovery']}</h2>
      <div class="content">
        <form action="" method="post" name="recover_password">
          <p>{$lang['you_have_forgotten_password']}</p>
          <p>
            {$lang['email']}: <input type="text" name="recover_email" />
            <input type="submit" name="submit_email" value="{$lang['submit']}" />
          </p>
        </form>
      </div>
    </div>
  </div>
  {show menu}
{/template}