{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template overall_header}
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="shortcut icon" href="{$settings['siteurl']}/favicon.ico" type="image/x-icon" />
<title>{(isset($template->title) ? $template->title .' - '. $settings['sitename'] : $settings['sitename'])}</title>
<link rel="stylesheet" type="text/css" href="{$settings['siteurl']}/templates/{$settings['template']}/admincp_style.css" />

<script type="text/javascript">
  var siteurl = "{$settings['siteurl']}/";
  {$template->load_js_lang()}
</script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/jquery.js"></script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/global.js"></script>
<script type="text/javascript" src="{$settings['siteurl']}/jscripts/admin.js"></script>
{$template->header}
</head>

{/template}

{template header}
<body>

<div id="top_shadow"></div>
<div id="shadow">
  <a href="{$settings['siteurl']}/"><img src="{$settings['siteurl']}/admin/images/onarcade_logo.gif" width="331" height="104" border="0" alt="onArcade" title="onArcade" style="margin-left: 15px;" id="logo" /></a>
  <div id="top_menu">
    <img src="images/on.png" alt="" />
    <ul>
      <li><a href="index.php">{$lang['main']}</a></li>
      <li><a href="files.php">{$lang['files']}</a></li>
      <li><a href="ads.php">{$lang['ads_links']}</a></li>
      <li><a href="forums.php">{$lang['forums_news']}</a></li>
      <li><a href="members.php">{$lang['members']}</a></li>
      <li><a href="templates.php">{$lang['templates']}</a></li>
      <li><a href="config.php">{$lang['settings']}</a></li>
    </ul>
  </div>
  <div id="main">
    <ul id="menu">
    {foreach (array)$txt['menu'] AS $menu}
      <li><a href="{$menu[0]}">{$menu[1]}</a></li>
    {/foreach}
    </ul>
    <div id="contents">

{/template}

{template footer}

    </div>
    <div class="clear"></div>
  </div>
</div>
<div id="bottom_shadow"></div>
<div id="powered">
  <!-- onArcade 2.4 -->
  Powered by <a href="http://www.onarcade.com" target="_blank">onArcade</a> v{$onarcade_version}
</div>

</body>


</html>
{/template}

{template main}
      <div class="left_column">
        <h2>{$lang['statistics']}</h2>
        <div class="left_column">
          {$lang['total_files']}: {$statistics->files} <a href="index.php?a=recount&amp;who=files"><img src="images/recount.png" alt="{$lang['recount']}" title="{$lang['recount']}" border="0" /></a><br />
          {$lang['total_members']}: {$statistics->members} <a href="index.php?a=recount&amp;who=members"><img src="images/recount.png" alt="{$lang['recount']}" title="{$lang['recount']}" border="0" /></a><br />
          {$lang['users_online']}: {$statistics->online}
        </div>
        <div class="right_column">
          <p>{$lang['played_today']}: {$statistics->played_today}</p>
          <p>{$lang['overall_played']}: {$statistics->total_played}</p>
        </div>
        <div class="clear"></div>
        <p>
          <a href="index.php?a=clear_cache" class="button">{$lang['clear_cache']}</a>
          <a href="index.php?a=reset_related" class="button">{$lang['reset_related']}</a>
        </p>
      </div>
      <div class="right_column">
        <h2>{$lang['notifications']}</h2>
  {foreach $txt['notices'] as $notice}
        <p class="error"><a href="{$notice[0]}">{$notice[1]}</a></p>
    {/foreach}
      </div>
      <div class="clear"></div>
      <h2>{$lang['news']}</h2>
  {foreach $txt['news'] as $news}
      <p><span class="bold">{$news['title']}</span> ({(format_date($news['date'], 3))})</p>
      <p>{$news['text']}</p>
      <div class="separator"></div>
  {/foreach}
			<p class="txt_right"><a href="http://wiki.onarcade.com" target="_blank"><img src="images/help.png" alt="" /></a></p>
{/template}

{template statistics}
      <div style="margin-bottom:6px;"><canvas id="statistics_graph" width="810" height="245"></canvas></div>
      <table id="statistics">
        <thead>
          <tr>
            <td>{$lang['date']}</td>
            <td>{$lang['played_times']}</td>
            <td>{$lang['overall_played']}</td>
            <td>{$lang['total_members']}</td>
            <td>{$lang['total_files']}</td>
			<td>{$lang['scores']}</td>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
      <form id="delete_form">
        <p>
          {$lang['delete_stats']}
          <input type="submit" value="{$lang['submit']}" />
        </p>
      </form>
      <script type="text/javascript">
    stats.data = {$txt['stats']};
    stats.init();
      </script>
{/template}

{template bots}
      <ul class="tab_menu" id="bots_tabs">
        <li><a href="">{$lang['bots']}</a></li>
        <li><a href="">{$lang['add_bot']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
      </ul>
      <div>
        <div>
          <!-- bot table -->
          <table id="bots">
            <thead>
              <tr>
                <td style="width:300px;">{$lang['name']}</td>
                <td>{$lang['user_agent']}</td>
                <td style="width:200px;">{$lang['last_visit']}</td>
                <td style="width:40px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
        <div>
          <!-- bot adding form -->
          <form action="" method="post" id="bot_form">
            <div class="line">
              <p>{$lang['name']}:</p>
              <p><input type="text" name="name" /></p>
            </div>
            <div class="line">
              <p>{$lang['user_agent']}:</p>
              <p><input type="text" name="user_agent" /></p>
            </div>
            <p><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div></div>
      </div>
      <script type="text/javascript">
    bots.data = {$txt['bots']};
    bots.init();
      </script>
{/template}

{template maintenance}
      <div class="left_column">
        <p><a href="index.php?a=maintenance&amp;task=optimize_db" class="button">{$lang['optimize_db']}</a></p>
        <p><a href="index.php?a=maintenance&amp;task=phpinfo" class="button">{$lang['php_info']}</a></p>
      </div>
      <div class="right_column">
        <p><a href="index.php?a=maintenance&amp;task=db_backup" class="button">{$lang['backup_db']}</a></p>
      </div>
      <div class="clear"></div>
{/template}

{template files}
      <ul class="tab_menu" id="files_tabs">
        <li><a href="">{$lang['files']}</a></li>
        <li><a href="">{$lang['add_file']}</a></li>
        <li><a href="">Youtube</a></li>
        <li><a href="">{$lang['tar_installer']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
        <li><a href="">{$lang['comments']}</a></li>
        <li><a href="">{$lang['scores']}</a></li>
        <li><a href="">{$lang['plugs']}</a></li>
        <li><a href="">{$lang['add_plug']}</a></li>
      </ul>
      <div>
        <div>
          <!-- files form -->
          <form id="files_form">
            <table id="files">
              <thead>
                <tr>
                  <td>{$lang['title']}</td>
                  <td style="width:150px;">{$lang['category']}</td>
                  <td style="width:100px;">{$lang['file_type']}</td>
                  <td style="width:100px;">{$lang['date']}</td>
                  <td style="width:100px;">{$lang['status']}</td>
                  <td style="width:20px;"></td><td style="width:20px;"></td>
                  <td style="width:20px;"></td><td style="width:20px;"></td>
                  <td style="width:30px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
                </tr>
              </thead>
              <tbody></tbody>
              <tfoot></tfoot>
            </table>
            <p class="txt_right">
              <select name="files_action">
                <option value="delete">{$lang['delete']}</option>
                <option value="active">{$lang['mark_active']}</option>
                <option value="inactive">{$lang['mark_inactive']}</option>
                <option value="game_activator">{$lang['game_activator']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
          <form id="search_form">
            <p class="txt_right">
              <input type="text" />
              <input type="submit" value="{$lang['search']}" />
            </p>
          </form>
        </div>
        <div>
          <!-- add file form -->
          <form id="add_file_from">
            <div class="line">
              <p>{$lang['title']}:</p>
              <p><input type="text" name="title" /></p>
            </div>
            <div class="line">
              <p>{$lang['description']}:</p>
              <p><textarea name="description"></textarea></p>
            </div>
            <div class="line">
              <p>{$lang['keywords']}:</p>
              <p><input type="text" name="keywords" class="long" /></p>
            </div>
            <div class="line">
              <p>{$lang['category']}:</p>
              <p><select name="category"></select></p>
            </div>
            <div class="line">
              <p>{$lang['file_type']}:</p>
              <p><select name="file_type"></select></p>
            </div>
            <div class="line">
              <p>{$lang['file']}</p>
              <div class="file_field">
                <p>
                  <input type="text" name="file" />
                  <img src="images/delete.png" class="file_delete click" title="{$lang['delete']}" alt="{$lang['delete']}" />
                  <img src="images/download.png" class="file_download click" title="{$lang['download']}" alt="{$lang['download']}" />
                  <img src="images/upload.png" class="file_upload click" title="{$lang['upload']}" alt="{$lang['upload']}" />
                  <img src="images/select.png" class="file_select click" title="{$lang['select']}" alt="{$lang['select']}" />
                  <img src="images/preview.png" class="file_preview click" title="{$lang['preview_file']}" alt="{$lang['preview_file']}" />
                </p>
                <p><select name="file_location"><option value="1">{$lang['local']}</option><option value="2">{$lang['linked']}</option><option value="3">{$lang['frame']}</option></select></p>
                <p>
                  <input type="text" name="width" class="small" /> x <input type="text" name="height" class="small" />
                  <img src="images/get_dimensions.png" class="file_get_dimensions click" title="{$lang['get_dimensions']}" alt="{$lang['get_dimensions']}" />
                  <img src="images/maximize.png" class="file_max_dimensions click" title="{$lang['maximize']}" alt="{$lang['maximize']}" />
                </p>
              </div>
            </div>
            <div class="line">
              <p><textarea name="custom_code" class="comment"></textarea></p>
            </div>
            <div class="line">
              <p>{$lang['image']}:</p>
              <div class="file_image_field">
                <p>
                  <input type="text" name="image" />
                  <img src="images/delete.png" class="file_delete click" title="{$lang['delete']}" alt="{$lang['delete']}" />
                  <img src="images/download.png" class="file_download click" title="{$lang['download']}" alt="{$lang['download']}" />
                  <img src="images/upload.png" class="file_upload click" title="{$lang['upload']}" alt="{$lang['upload']}" />
                  <img src="images/select.png" class="file_select click" title="{$lang['select']}" alt="{$lang['select']}" />
                  <img src="images/preview.png" class="file_preview click" title="{$lang['preview_file']}" alt="{$lang['preview_file']}" />
                </p>
                <p><select name="image_location"><option value="1">{$lang['local']}</option><option value="2">{$lang['linked']}</option></select></p>
              </div>
            </div>
            <div class="line">
              <p>{$lang['status']}:</p>
              <p><select name="status"><option value="1">{$lang['active']}</option><option value="2">{$lang['inactive']}</option><option value="3">{$lang['game_activator']}</option></select></p>
            </div>
            <div class="line">
              <p>{$lang['adult']}:</p>
              <p><select name="adult"><option value="0">{$lang['off']}</option><option value="1">{$lang['on']}</option></select></p>
            </div>
            <div class="line">
              <p>{$lang['scores']}:</p>
              <p><select name="scores"><option value="0">{$lang['off']}</option><option value="1">{$lang['on']}</option></select></p>
            </div>
            <div class="scores_variables">
              <div class="line">
                <p>{$lang['score_type']}:</p>
                <p><select name="score_type"><option value="1">{$lang['high']}</option><option value="2">{$lang['low']}</option></select></p>
              </div>
              <div class="line">
                <p>gname / game_name:</p>
                <p><input type="text" name="score_name" /></p>
              </div>
            </div>
            <div class="left_column">
              <div class="line">
                <p>{$lang['sponsor']}:</p>
                <p><input type="text" name="sponsor_title" /></p>
              </div>
            </div>
            <div class="right_column">
              <div class="line">
                <p>{$lang['url']}:</p>
                <p><input type="text" name="sponsor_url" /></p>
              </div>
            </div>
            <div class="clear"></div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- Youtube downloader -->
          <form id="youtube_form">
            <div class="line">
              <p>{$lang['url']}</p>
              <p>
                <input type="text" name="url" class="long" />
                <input type="submit" value="{$lang['download']}" /><br />
                <label><input type="checkbox" name="download" value="1" /> {$lang['download_video']}</label>
              </p>
            </div>
          </form>
        </div>
        <div>
          <!-- tar installer -->
          <form id="tar_form" method="post" enctype="multipart/form-data">
            <div class="line">
              <p>{$lang['file']}</p>
              <p>
                <input type="file" name="file" />
                <input type="submit" value="{$lang['submit']}" />
              </p>
            </div>
          </form>
        </div>
        <div>
          <!-- edit file form -->
        </div>
        <div>
          <!-- comments table -->
          <table id="comments">
            <thead>
              <tr>
                <td>{$lang['comment']}</td>
                <td style="width:120px;">{$lang['user']}</td>
                <td style="width:100px;">{$lang['ip']}</td>
                <td style="width:110px;">{$lang['date']}</td>
                <td style="width:100px;">{$lang['status']}</td>
                <td style="width:30px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
        <div>
          <!-- scores table -->
          <table id="scores">
            <thead>
              <tr>
                <td style="width:40px;">#</td>
                <td style="width:150px;">{$lang['user']}</td>
                <td style="width:120px;">{$lang['score']}</td>
                <td>{$lang['comment']}</td>
                <td style="width:100px;">{$lang['ip']}</td>
                <td style="width:120px;">{$lang['date']}</td>
                <td style="width:25px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
            <tfoot></tfoot>
          </table>
        </div>
        <div>
          <!-- plugs table -->
          <table id="plugs">
            <thead>
              <tr>
                <td style="width:150px;">{$lang['link']}</td>
                <td>{$lang['url']}</td>
                <td style="width:90px;">{$lang['out_today']}</td>
                <td style="width:90px;">{$lang['out_yesterday']}</td>
                <td style="width:90px;">{$lang['out_total']}</td>
                <td style="width:25px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
            <tfoot></tfoot>
          </table>
        </div>
        <div>
          <!-- add plug form -->
          <form id="add_plug_form">
            <div class="line">
              <p>{$lang['link']}:</p>
              <p><select name="link"></select></p>
            </div>
            <div class="line">
              <p>{$lang['url']}:</p>
              <p><input type="text" name="url" class="long" /></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
      </div>
      <script type="text/javascript">
    files.data = {$txt['files']};
    files.pages = {$txt['pages']};
    files.status = {$txt['status']};
    files.categories = {$txt['categories']};
    files.file_types = {$txt['file_types']};
    files.filesdir = "{$settings['filesdir']}";
    files.max_file_width = {$settings['max_file_width']};
    files.max_file_height = {$settings['max_file_height']};
    files.comment_status = {$txt['comment_status']};
    files.init();
      </script>
{/template}

{template approve_files}
    <form id="approve_form">
      <table id="files">
        <thead>
          <tr>
            <td>{$lang['title']}</td>
            <td style="width:150px;">{$lang['category']}</td>
            <td style="width:100px;">{$lang['file_type']}</td>
            <td style="width:110px;">{$lang['date']}</td>
            <td style="width:120px;">{$lang['added_by']}</td>
            <td style="width:20px;"></td>
            <td style="width:20px;"></td>
            <td style="width:25px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
        <p class="txt_right">
          <select name="approve_action">
            <option value="approve">{$lang['approve']}</option>
            <option value="delete">{$lang['delete']}</option>
          </select>
          <input type="submit" value="{$lang['go']}" />
        </p>
      </form>
      <script type="text/javascript">
    approve_files.data = {$txt['files']};
    approve_files.categories = {$txt['categories']};
    approve_files.file_types = {$txt['file_types']};
    approve_files.init();
      </script>
{/template}

{template broken_files}
      <form id="broken_form">
        <table id="files">
          <thead>
            <tr>
              <td style="width:175px;">{$lang['title']}</td>
              <td>{$lang['comment']}</td>
              <td style="width:120px;">{$lang['user']}</td>
              <td style="width:100px;">{$lang['ip']}</td>
              <td style="width:110px;">{$lang['date']}</td>
              <td style="width:25px;"></td>
              <td style="width:25px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
        <p class="txt_right">
          <select name="broken_action">
            <option value="delete_report">{$lang['delete_report']}</option>
            <option value="delete_file">{$lang['delete_file']}</option>
          </select>
          <input type="submit" value="{$lang['go']}" />
        </p>
      </form>
      <script type="text/javascript">
    broken.data = {$txt['broken']};
    broken.init();
      </script>
{/template}

{template comments}
      <ul class="tab_menu" id="comments_tabs">
        <li><a href="">{$lang['comments']}</a></li>
        <li><a href="">{$lang['approve_comments']}</a></li>
        <li><a href="">{$lang['reported_comments']}</a></li>
      </ul>
      <div>
        <div>
          <!-- comments table -->
          <form id="comments_form">
            <table id="comments">
              <thead>
                <tr>
                  <td>{$lang['comment']}</td>
                  <td style="width:100px;">{$lang['user']}</td>
                  <td style="width:100px;">{$lang['file']}</td>
                  <td style="width:100px;">{$lang['ip']}</td>
                  <td style="width:100px;">{$lang['date']}</td>
                  <td style="width:100px;">{$lang['status']}</td>
                  <td style="width:30px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
               </tr>
              </thead>
              <tbody></tbody>
              <tfoot></tfoot>
            </table>
            <p class="txt_right">
              <select name="comments_action">
                <option value="approve">{$lang['approve']}</option>
                <option value="delete">{$lang['delete']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
        </div>
        <div>
          <!-- approve comments table -->
          <form id="approve_comments_form">
            <table id="approve_comments">
              <thead>
                <tr>
                  <td>{$lang['comment']}</td>
                  <td style="width:100px;">{$lang['user']}</td>
                  <td style="width:100px;">{$lang['file']}</td>
                  <td style="width:100px;">{$lang['ip']}</td>
                  <td style="width:100px;">{$lang['date']}</td>
                  <td style="width:30px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
               </tr>
              </thead>
              <tbody></tbody>
            </table>
            <p class="txt_right">
              <select name="comments_action">
                <option value="approve">{$lang['approve']}</option>
                <option value="delete">{$lang['delete']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
        </div>
        <div>
          <!-- reported comments table -->
          <form id="reported_comments_form">
            <table id="reported_comments">
              <thead>
                <tr>
                  <td>{$lang['comment']}</td>
                  <td style="width:100px;">{$lang['user']}</td>
                  <td style="width:100px;">{$lang['file']}</td>
                  <td style="width:100px;">{$lang['ip']}</td>
                  <td style="width:100px;">{$lang['times_reported']}</td>
                  <td style="width:30px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
               </tr>
              </thead>
              <tbody></tbody>
            </table>
            <p class="txt_right">
              <select name="comments_action">
                <option value="delete_report">{$lang['delete_report']}</option>
                <option value="delete">{$lang['delete_comment']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
        </div>
      </div>
      <script type="text/javascript">
    comments.data = {$txt['comments']};
    comments.pages = {$txt['pages']};
    comments.status = {$txt['status']};
    comments.init();
      </script>
{/template}

{template game_feeds}
      <form id="feed_form">
        <p>
          {$lang['feed']}:
          <select name="feed"></select>
        </p>
        <p>
          {$lang['category']}:
          <select name="category"></select>
        </p>
        <p>
          {$lang['search']}:
          <input type="text" name="search" />
        </p>
        <p><input type="submit" value="{$lang['submit']}" /></p>
        <div class="clear"></div>
		<p>
          {$lang['language']}:
          <select name="language"></select>
        </p>
		<div class="clear"></div>
        <p><label>{$lang['only_without_ads']} <input type="checkbox" name="without_ads" value="1" /></label></p>
        <p><label>{$lang['only_positive_rating']} <input type="checkbox" name="positive_rating" value="1" /></label></p>
        <p><label>{$lang['only_with_scores']} <input type="checkbox" name="scores" value="1" /></label></p>
        <p><label>{$lang['only_mobile_games']} <input type="checkbox" name="mobile" value="1" /></label></p>
        <div class="separator"></div>
        <div id="games"></div>
        <div class="clear"></div>
        <div id="navigation" class="arrow_nav"></div>
      </form>
      <script type="text/javascript">
    game_feeds.games = {$txt['games']};
    game_feeds.feeds = {$txt['feeds']};
    game_feeds.languages = {$txt['languages']};
	{if isset($txt['language'])}
    game_feeds.language = {$txt['language']};
	{/if}
    game_feeds.categories = {$txt['categories']};
    game_feeds.real_categories = {$txt['real_categories']};
    game_feeds.status = {$txt['status']};
    game_feeds.next = {$txt['next']};
    game_feeds.image_width = {$settings['image_width']};
    game_feeds.image_height = {$settings['image_height']};
    game_feeds.init();
      </script>
{/template}

{template install_gp}
      <p>{$lang['choose_gb']}</p>
  {foreach $txt['packs'] as $number => $pack}
      <p class="game_pack">
        <a href="files.php?a=install_gp&amp;id={$pack['id']}">{$pack['name']}</a>
        <span>({$pack['files']})</span>
      </p>
    {if $number % 4 == 3}
      <div class="clear"></div>
    {/if}
  {/foreach}
{/template}

{template game_pack}
    {if $txt['installed']}
      <p class="error">{$lang['pack_installed']}</p>
    {/if}
      <form id="install_pack">
        <div class="line">
          <p>{$lang['name']}:</p>
          <p>{$txt['pack']['name']}</p>
        </div>
        <div class="line">
          <p>{$lang['number_files']}:</p>
          <p>{$txt['pack']['files']}</p>
        </div>
        <div class="line">
          <p>{$lang['status']}:</p>
          <p><select name="status"><option value="1">{$lang['active']}</option><option value="2">{$lang['inactive']}</option><option value="3">{$lang['game_activator']}</option></select></p>
        </div>
        <div class="line">
          <p>{$lang['duplicated_titles']}:</p>
          <p><select name="duplicated_titles"><option value="0">{$lang['install']}</option><option value="1">{$lang['skip']}</option></select></p>
        </div>
        <div class="line">
          <p>{$lang['duplicated_files']}:</p>
          <p><select name="duplicated_files"><option value="0">{$lang['rename']}</option><option value="1">{$lang['skip']}</option></select></p>
        </div>
        <p class="center"><input type="submit" value="{$lang['install']}" /></p>
      </form>
      <div id="game_pack_installation">
        <p class="center">{$lang['installed']}: <span class="bold">x</span> / <span>y</span></p>
        <div class="loader"><div class="loaded"></div></div>
        <p class="bold center">{$lang['do_not_close']}</p>
        <button>{$lang['close']}</button>
      </div>
      <script type="text/javascript">
    game_packs.pack_id = {$txt['pack']['id']};
    game_packs.files = {$txt['pack']['files']};
    game_packs.init();
      </script>
      <h2>{$lang['files_in_pack']}:</h2>
  {foreach $txt['pack']['data'] as $number => $file}
      <p class="game_pack">
        {$file['title']}
      </p>
    {if $number % 4 == 3}
      <div class="clear"></div>
    {/if}
  {/foreach}
{/template}

{template categories}
      <ul class="tab_menu" id="categories_tabs">
        <li><a href="">{$lang['categories']}</a></li>
        <li><a href="">{$lang['add_category']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
      </ul>
      <div>
        <div>
          <!-- delete category form -->
          <form id="delete_category_form">
            <p>{$lang['move_files']}</p>
            <p><select name="new_category"></select></p>
            <p><input type="submit" value="{$lang['submit']}" /></p>
          </form>
          <table id="categories">
            <thead>
              <tr>
                <td>{$lang['title']}</td>
                <td style="width:100px;">{$lang['permissions']}</td>
                <td style="width:100px;">{$lang['status']}</td>
                <td style="width:60px;">{$lang['order']}</td>
                <td style="width:150px;">{$lang['parent']}</td>
                <td style="width:50px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
        <div>
          <!-- add category form -->
          <form id="add_category_form">
            <div class="line">
              <p>{$lang['title']}:</p>
              <p><input type="text" name="title" maxlength="50" /></p>
            </div>
            <div class="line">
              <p>{$lang['description']}:</p>
              <p><textarea name="description"></textarea></p>
            </div>
            <div class="line">
              <p>{$lang['keywords']}:</p>
              <p><input type="text" name="keywords" /></p>
            </div>
            <div class="line">
              <p>{$lang['permissions']}:</p>
              <p><select name="permissions"><option value="1">{$lang['everybody']}</option><option value="2">{$lang['members_only']}</option></select></p>
            </div>
            <div class="line">
              <p>{$lang['status']}:</p>
              <p><select name="status"><option value="1">{$lang['active']}</option><option value="0">{$lang['inactive']}</option></select></p>
            </div>
            <div class="line">
              <p>{$lang['order']}:</p>
              <p><input type="text" name="order" class="small" /></p>
            </div>
            <div class="line">
              <p>{$lang['parent']}:</p>
              <p><select name="parent"></select></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div></div>
      </div>
      <script type="text/javascript">
    categories.data = {$txt['categories']};
    categories.permissions = {$txt['permissions']};
    categories.status = {$txt['status']};
    categories.init();
      </script>
{/template}

{template custom_pages}
      <ul class="tab_menu" id="pages_tabs">
        <li><a href="">{$lang['custom_pages']}</a></li>
        <li><a href="">{$lang['add_custom_page']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
      </ul>
      <div>
        <div>
          <table id="custom_pages">
            <thead>
              <tr>
                <td style="width:150px;">{$lang['title']}</td>
                <td>{$lang['description']}</td>
                <td style="width:110px;">{$lang['status']}</td>
                <td style="width:20px;"></td><td style="width:40px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
        <div>
          <!-- add custom page form -->
          <form id="add_page_form">
            <div class="line">
              <p>{$lang['id']}:</p>
              <p><input type="text" name="page_id" maxlength="25" /></p>
            </div>
            <div class="line">
              <p>{$lang['title']}:</p>
              <p><input type="text" name="title" maxlength="50" /></p>
            </div>
            <div class="line">
              <p>{$lang['description']}:</p>
              <p><input type="text" name="description" maxlength="255" /></p>
            </div>
            <div class="line">
              <p>{$lang['keywords']}:</p>
              <p><input type="text" name="keywords" maxlength="255" /></p>
            </div>
            <div class="line">
              <p>{$lang['content']}:</p>
              <p><textarea name="content" class="post"></textarea></p>
            </div>
            <div class="line">
              <p>{$lang['status']}:</p>
              <p><select name="status"><option value="1">{$lang['active']}</option><option value="0">{$lang['inactive']}</option></select></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- edit custom page form -->
        </div>
      </div>
      <script type="text/javascript">
    cpages.data = {$txt['pages']};
    cpages.status = {$txt['status']};
    cpages.init();
      </script>
{/template}

{template cups}
      <ul class="tab_menu" id="cups_tabs">
        <li><a href="">{$lang['cups']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
      </ul>
      <div>
        <div>
          <table id="cups">
            <thead>
              <tr>
                <td>{$lang['name']}</td>
                <td style="width:110px;">{$lang['creator']}</td>
                <td style="width:110px;">{$lang['created']}</td>
                <td style="width:110px;">{$lang['closing']}</td>
                <td style="width:40px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
			<tfoot></tfoot>
          </table>
        </div>
        <div>
          <!-- edit cup form -->
          <form id="edit_cup_form">
            <div class="line">
              <p>{$lang['name']}:</p>
              <p><input type="text" name="name" /></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
      </div>
      <p class="txt_right"><a href="http://wiki.onarcade.com/index.php/OnArcade_2.4:_Cups" target="_blank"><img src="images/help.png" alt="" /></a></p>
      <script type="text/javascript">
		cups.pages = {$cups_pages};
		cups.data = {$cups};
		cups.init();
      </script>
{/template}

{template ads}
      <ul class="tab_menu" id="ads_tabs">
        <li><a href="">{$lang['ads']}</a></li>
        <li><a href="">{$lang['add_ad']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
        <li><a href="">{$lang['ad_zones']}</a></li>
        <li><a href="">{$lang['add_zone']}</a></li>
      </ul>
      <div>
        <div>
          <!-- ads table -->
          <form id="ads_form">
            <table id="ads">
              <thead>
                <tr>
                  <td style="width:60px;">#</td>
                  <td>{$lang['zone']}</td>
                  <td style="width:150px;">{$lang['date']}</td>
                  <td style="width:150px;">{$lang['status']}</td>
                  <td style="width:30px;"></td>
                  <td style="width:30px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
            <p class="txt_right">
              <select name="ads_action">
                <option value="delete">{$lang['delete']}</option>
                <option value="active">{$lang['mark_active']}</option>
                <option value="inactive">{$lang['mark_inactive']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
        </div>
        <div>
          <!-- add ad form -->
          <form id="add_ad_form">
            <div class="line">
              <p>{$lang['code']}:</p>
              <p><textarea name="code" class="comment"></textarea></p>
            </div>
            <div class="line">
              <p>{$lang['zone']}:</p>
              <p><select name="zone"></select></p>
            </div>
            <div class="line">
              <p>{$lang['status']}:</p>
              <p><select name="status"><option value="1">{$lang['active']}</option><option value="0">{$lang['inactive']}</option></select></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div></div>
        <div>
          <!-- ad zones table -->
          <p>{$lang['place_zone_code_template']}</p>
          <table id="ad_zones">
            <thead>
              <tr>
                <td>{$lang['name']}</td>
                <td style="width:250px;">{$lang['code']}</td>
                <td style="width:30px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
        <div>
          <!-- add ad zone form -->
          <form id="add_ad_zone_form">
            <div class="line">
              <p>{$lang['name']}:</p>
              <p><input type="text" name="name" /></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
      </div>
      <script type="text/javascript">
    ads.data = {$txt['ads']};
    ads.zones = {$txt['zones']};
    ads.status = {$txt['status']};
    ads.zones_data = {$txt['zones_data']};
    ads.init();
      </script>
{/template}

{template links}
      <ul class="tab_menu" id="links_tabs">
        <li><a href="">{$lang['links']}</a></li>
        <li><a href="">{$lang['add_link']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
        <li><a href="">{$lang['plugs']}</a></li>
        <li><a href="">{$lang['add_plug']}</a></li>
      </ul>
      <div>
        <div>
          <!-- links table -->
          <form id="links_form">
            <table id="links">
              <thead>
                <tr>
                  <td>{$lang['url']}</td>
                  <td style="width:70px;">{$lang['in_today']}</td>
                  <td style="width:70px;">{$lang['in_yesterday']}</td>
                  <td style="width:70px;">{$lang['in_total']}</td>
                  <td style="width:70px;">{$lang['out_today']}</td>
                  <td style="width:70px;">{$lang['out_yesterday']}</td>
                  <td style="width:70px;">{$lang['out_total']}</td>
                  <td style="width:90px;">{$lang['status']}</td>
                  <td style="width:70px;"></td>
                  <td style="width:20px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
                </tr>
              </thead>
              <tbody></tbody>
            </table>
            <p class="txt_right">
              <select name="links_action">
                <option value="delete">{$lang['delete']}</option>
                <option value="active">{$lang['mark_active']}</option>
                <option value="inactive">{$lang['mark_inactive']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
        </div>
        <div>
          <!-- add ad form -->
          <form id="add_link_form">
            <div class="line">
              <p>{$lang['title']}:</p>
              <p><input type="text" name="title" /></p>
            </div>
            <div class="line">
              <p>{$lang['url']}:</p>
              <p><input type="text" name="url" class="long" /></p>
            </div>
            <div class="line">
              <p>{$lang['description']}:</p>
              <p><textarea name="description"></textarea></p>
            </div>
            <div class="line">
              <p>{$lang['email']}:</p>
              <p><input type="text" name="email" /></p>
            </div>
            <div class="line">
              <p>{$lang['status']}:</p>
              <p><select name="status"><option value="1">{$lang['active']}</option><option value="2">{$lang['inactive']}</option></select></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- edit ad form -->
        </div>
        <div>
          <!-- plugs table -->
          <table id="plugs">
            <thead>
              <tr>
                <td style="width:200px;">{$lang['file']}</td>
                <td>{$lang['url']}</td>
                <td style="width:90px;">{$lang['out_today']}</td>
                <td style="width:90px;">{$lang['out_yesterday']}</td>
                <td style="width:90px;">{$lang['out_total']}</td>
                <td style="width:25px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
            <tfoot></tfoot>
          </table>
        </div>
        <div>
          <!-- add plug form -->
          <form id="add_plug_form">
            <div class="line">
              <p>{$lang['file']}:</p>
              <p><select name="file"></select></p>
            </div>
            <div class="line">
              <p>{$lang['url']}:</p>
              <p><input type="text" name="url" class="long" /></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
      </div>
      <script type="text/javascript">
    links.data = {$txt['links']};
    links.status = {$txt['status']};
    links.init();
      </script>
{/template}

{template approve_links}
      <form id="links_form">
        <table id="links">
          <thead>
            <tr>
              <td style="width:150px;">{$lang['url']}</td>
              <td>{$lang['description']}</td>
              <td style="width:150px;">{$lang['email']}</td>
              <td style="width:120px;">{$lang['ip']}</td>
              <td style="width:20px;"></td>
              <td style="width:20px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
            </tr>
          </thead>
          <tbody></tbody>
        </table>
        <p class="txt_right">
          <select name="links_action">
            <option value="active">{$lang['mark_active']}</option>
            <option value="delete">{$lang['delete']}</option>
          </select>
          <input type="submit" value="{$lang['go']}" />
        </p>
      </form>
      <script type="text/javascript">
    approve_links.data = {$txt['links']};
    approve_links.init();
      </script>
{/template}

{template forums}
      <ul class="tab_menu" id="forums_tabs">
        <li><a href="">{$lang['forums']}</a></li>
        <li><a href="">{$lang['add_forum']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
        <li><a href="">{$lang['add_category']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
      </ul>
      <div>
        <div>
          <!-- delete forum form -->
          <form id="delete_forum_form">
            <p>{$lang['do_topics_forum']}</p>
            <p>
              <input type="submit" name="delete_topics" value="{$lang['delete']}" />
              {$lang['or_move_to']}
            </p>
            <p><select name="new_forum"></select></p>
            <p><input type="submit" name="move_topics" value="{$lang['submit']}" /></p>
          </form>
          <!-- delete category form -->
          <form id="delete_category_form">
            <p>{$lang['move_forums']}</p>
            <p><select name="new_category"></select></p>
            <p><input type="submit" value="{$lang['submit']}" /></p>
          </form>
          <!-- forums table -->
          <table id="forums_table">
            <thead>
              <tr>
                <td>{$lang['forum']}</td><td style="width:60px;">{$lang['order']}</td><td style="width:50px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
        <div>
          <!-- add forum form -->
          <form id="add_forum_form">
            <div class="line">
              <p>{$lang['title']}:</p>
              <p><input type="text" name="title" /></p>
            </div>
            <div class="line">
              <p>{$lang['description']}:</p>
              <p><textarea name="description"></textarea></p>
            </div>
            <div class="line">
              <p>{$lang['category']}:</p>
              <p>
                <select name="category"></select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['order']}:</p>
              <p><input type="text" name="order" class="small" /></p>
            </div>
            <div class="line">
              <p>{$lang['post_topics']}:</p>
              <p><select name="topic_permission"><option value="0">{$lang['everybody']}</option><option value="1">{$lang['members_only']}</option><option value="2">{$lang['admin_only']}</option></select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['post_replies']}:</p>
              <p><select name="reply_permission"><option value="0">{$lang['everybody']}</option><option value="1">{$lang['members_only']}</option><option value="2">{$lang['admin_only']}</option></select></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- edit forum form -->
        </div>
        <div>
          <!-- add category form -->
          <form id="add_category_form">
            <div class="line">
              <p>{$lang['title']}:</p>
              <p><input type="text" name="title" /></p>
            </div>
            <div class="line">
              <p>{$lang['order']}:</p>
              <p><input type="text" name="order" class="small" /></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- edit category form -->
        </div>
      </div>
      <script type="text/javascript">
    forums.data = {$txt['forums']};
    forums.categories = {$txt['categories']};
    forums.init();
      </script>
{/template}

{template news}
      <ul class="tab_menu" id="news_tabs">
        <li><a href="">{$lang['news']}</a></li>
        <li><a href="">{$lang['add_news']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
      </ul>
      <div>
        <div>
          <!-- news table -->
          <form id="news_form">
  {if $settings['news'] == 2}
            <p class="error">{$lang['news_from_forums']}</p>
  {/end}
            <table id="new_table">
              <thead>
                <tr>
                  <td>{$lang['title']}</td><td style="width:120px;">{$lang['author']}</td><td style="width:150px;">{$lang['date']}</td><td style="width:90px;">{$lang['status']}</td><td style="width:30px;"></td><td style="width:30px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
                </tr>
              </thead>
              <tbody></tbody>
              <tfoot></tfoot>
            </table>
            <p class="txt_right">
              <select name="news_action">
                <option value="delete">{$lang['delete']}</option>
                <option value="active">{$lang['mark_active']}</option>
                <option value="inactive">{$lang['mark_inactive']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
        </div>
        <div>
          <!-- add news form -->
          <form id="add_news_form">
            <div class="line">
              <p>{$lang['title']}:</p>
              <p><input type="text" name="title" /></p>
            </div>
            <div class="line">
              <p>{$lang['message']}:</p>
              <div>
                <div id="bb_code"></div>
                <p><textarea name="message" id="message" class="post"></textarea></p>
              </div>
            </div>
            <div class="line">
              <p>{$lang['status']}:</p>
              <p><select name="status"><option value="1">{$lang['active']}</option><option value="0">{$lang['inactive']}</option></select></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- edit news form -->
          <form id="edit_news_form">
            <div class="line">
              <p>{$lang['title']}:</p>
              <p><input type="text" name="title" /></p>
            </div>
            <div class="line">
              <p>{$lang['message']}:</p>
              <div>
                <div id="edit_bb_code"></div>
                <p><textarea name="message" id="edit_message" class="post"></textarea></p>
              </div>
            </div>
            <div class="line">
              <p>{$lang['status']}:</p>
              <p><select name="status"><option value="1">{$lang['active']}</option><option value="0">{$lang['inactive']}</option></select></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
      </div>
      <script type="text/javascript">
    news.data = {$txt['news']};
    news.pages = {$txt['pages']};
    news.status = {$txt['status']};
    news.init();
      </script>
{/template}

{template members}
      <ul class="tab_menu" id="members_tabs">
        <li><a href="">{$lang['members']}</a></li>
        <li><a href="">{$lang['add_member']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
        <li><a href="">{$lang['comments']}</a></li>
      </ul>
      <div>
        <div>
          <!-- users form -->
          <form id="users_form">
            <table id="members">
              <thead>
                <tr>
                  <td>{$lang['username']}</td>
                  <td style="width:180px;">{$lang['joined']}</td>
                  <td style="width:150px;">{$lang['user_group']}</td>
                  <td style="width:150px;">{$lang['status']}</td>
                  <td style="width:50px;"></td>
                  <td style="width:30px;"><input type="checkbox" name="all" onclick="check_all(this);" /></td>
                </tr>
              </thead>
              <tbody></tbody>
              <tfoot></tfoot>
            </table>
            <p class="txt_right">
              <select name="members_action">
                <option value="delete">{$lang['delete']}</option>
                <option value="active">{$lang['mark_active']}</option>
                <option value="ban">{$lang['ban']}</option>
              </select>
              <input type="submit" value="{$lang['go']}" />
            </p>
          </form>
          <form id="search_form">
            <p class="txt_right">
              <input type="text" />
              <input type="submit" value="{$lang['search']}" />
            </p>
          </form>
          <form id="remove_unconfirmed_form">
            <p>
              {$lang['delete_members_days']}
              <input type="submit" value="{$lang['submit']}" />
            </p>
          </form>
          <form id="remove_inactive_form">
            <p>
              {$lang['delete_inactive_members']}
              <input type="submit" value="{$lang['submit']}" />
            </p>
          </form>
        </div>
        <div>
          <!-- user adding form -->
          <form id="add_member_form">
            <div class="line">
              <p>{$lang['username']}:</p>
              <p><input type="text" name="username" maxlength="25" /></p>
            </div>
            <div class="line">
              <p>{$lang['email']}:</p>
              <p><input type="text" name="email" maxlength="40" /></p>
            </div>
            <div class="line">
              <p>{$lang['password']}:</p>
              <p><input type="password" name="password" /></p>
            </div>
            <div class="line">
              <p>{$lang['user_group']}:</p>
              <p>
                <select name="user_group">
                  <option value="1">{$lang['member']}</option>
                  <option value="2">{$lang['administrator']}</option>
                </select>
              </p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- user editing form -->
          <form id="edit_member_form">
            <div class="line">
              <p>{$lang['username']}:</p>
              <p><input type="text" name="username" maxlength="25" /></p>
            </div>
            <div class="line">
              <p>{$lang['email']}:</p>
              <p><input type="text" name="email" maxlength="40" /></p>
            </div>
            <div class="line">
              <p>{$lang['password']}:</p>
              <p><input type="password" name="password" /> ({$lang['only_change']})</p>
            </div>
            <div class="line">
              <p>{$lang['user_group']}:</p>
              <p>
                <select name="user_group">
                  <option value="1">{$lang['member']}</option>
                  <option value="2">{$lang['administrator']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['status']}:</p>
              <p>
                <select name="status">
                  <option value="1">{$lang['active']}</option>
                  <option value="2">{$lang['banned']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['joined']}:</p>
              <p id="edit_joined"></p>
            </div>
            <div class="line">
              <p>{$lang['last_visit']}:</p>
              <p id="edit_last_visit"></p>
            </div>
            <div class="line">
              <p>{$lang['ip']}:</p>
              <p id="edit_registration_ip"></p>
            </div>
            <div class="line">
              <p>{$lang['name']}:</p>
              <p><input type="text" name="name" /></p>
            </div>
            <div class="line">
              <p>{$lang['quote']}:</p>
              <p><textarea name="quote"></textarea></p>
            </div>
            <div class="line">
              <p>{$lang['location']}:</p>
              <p><input type="text" name="location" /></p>
            </div>
            <div class="line">
              <p>{$lang['gender']}:</p>
              <p>
                <select name="gender"><option value="0"></option><option value="1">{$lang['male']}</option><option value="2">{$lang['female']}</option></select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['website']}:</p>
              <p><input type="text" name="website" /></p>
            </div>
            <div class="left_column">
              <div class="line">
                <p>{$lang['msn']}:</p>
                <p><input type="text" name="msn" /></p>
              </div>
              <div class="line">
                <p>{$lang['skype']}:</p>
                <p><input type="text" name="skype" /></p>
              </div>
              <div class="line">
                <p>{$lang['icq']}:</p>
                <p><input type="text" name="icq" /></p>
              </div>
            </div>
            <div class="left_column">
              <div class="line">
                <p>{$lang['aim']}:</p>
                <p><input type="text" name="aim" /></p>
              </div>
              <div class="line">
                <p>{$lang['yahoo']}:</p>
                <p><input type="text" name="yahoo" /></p>
              </div>
              <div class="line">
                <p>{$lang['google_talk']}:</p>
                <p><input type="text" name="google_talk" /></p>
              </div>
            </div>
            <div class="clear"></div>
            <div class="line">
              <p>CSS:</p>
              <p><textarea name="css"></textarea></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- user comments table -->
          <table id="comment_table">
            <thead>
              <tr>
                <td>{$lang['comment']}</td>
                <td style="width:120px;">{$lang['file']}</td>
                <td style="width:100px;">{$lang['ip']}</td>
                <td style="width:110px;">{$lang['date']}</td>
                <td style="width:100px;">{$lang['status']}</td>
                <td style="width:30px;"></td>
              </tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
      </div>
      <script type="text/javascript">
    members.data = {$txt['members']};
    members.pages = {$txt['pages']};
    members.user_group = {$txt['user_group']};
    members.status = {$txt['status']};
    members.comment_status = {$txt['comment_status']};
    members.init();
      </script>
{/template}

{template mass_mail}
      <form action="" method="post">
  {if isset($txt['preview'])}
        <div id="mass_mail_preview">
          <p class="bold">{$lang['subject']}: {$txt['preview']['subject']}</p>
          <p>{$txt['preview']['message']}</p>
        </div>
  {/end}
  {if isset($txt['error'])}
        <p class="error">{$txt['error']}</p>
    {/end}
        <div class="line">
          <p>{$lang['subject']}:</p>
          <p><input type="text" name="subject" value="{$txt['message']['subject']}" /></p>
        </div>
        <div class="line">
          <p>{$lang['message']}:</p>
          <div>
            <p>({$lang['may_use_username']})</p>
            <p><textarea name="message" class="post">{$txt['message']['message']}</textarea></p>
          </div>
        </div>
        <div class="line">
          <p>{$lang['delivery_method']}:</p>
          <p><select name="delivery"><option value="1">{$lang['email']}</option><option value="2"{$txt['message']['pm']}>{$lang['private_message']}</option></select></p>
        </div>
        <p class="center">
          <input type="submit" name="submit_mail" value="{$lang['submit']}" />
          <input type="submit" name="preview_mail" value="{$lang['preview']}" />
        </p>
      </form>
{/template}

{template main_s}
      <form id="setting_form">
        <div class="line">
          <p>{$lang['site_title']}:</p>
          <p><input type="text" name="sitename" value="{$settings['sitename']}" /></p>
        </div>
        <div class="line">
          <p>{$lang['site_url']}:</p>
          <p><input type="text" name="siteurl" value="{$settings['siteurl']}" /></p>
        </div>
        <div class="line">
          <p>{$lang['site_status']}:</p>
          <p>
            <select name="siteonline">
              <option value="0">{$lang['offline']}</option>
              <option value="1"{($settings['siteonline']==1?' selected="selected"':'')}>{$lang['online']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['site_description']}:</p>
          <p><textarea name="sitedescription">{$settings['sitedescription']}</textarea></p>
        </div>
        <div class="line">
          <div>
            <p>{$lang['site_keywords']}:</p>
            <p class="normal">({$lang['separate_comma']})</p>
          </div>
          <p><textarea name="sitekeywords">{$settings['sitekeywords']}</textarea></p>
        </div>
        <div class="line">
          <p>{$lang['contact_email']}:</p>
          <p><input type="text" name="sitecontactemail" value="{$settings['sitecontactemail']}" /></p>
        </div>
        <div class="line">
          <p>{$lang['template']}:</p>
          <p>{$txt['template']}</p>
        </div>
        <div class="line">
          <p>{$lang['template_mobile']}:</p>
          <p>{$txt['template_mobile']}</p>
        </div>
        <div class="line">
          <p>{$lang['language']}:</p>
          <p>{$txt['language']}</p>
        </div>
        <div class="line">
          <p>{$lang['time_zone']}:</p>
          <p>{$txt['time_zone']}</p>
        </div>
        <div class="line">
          <p>{$lang['image_verification']}:</p>
          <p>
            <select name="image_verification">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['image_verification'] == 1 ?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['cache']}:</p>
          <p>
            <select name="cache">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['cache'] == 1 ?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['cache_time']}:</p>
          <p><input type="text" name="cache_expire" value="{$settings['cache_expire']}" class="small" /> {$lang['minutes']}</p>
        </div>
        <div class="line">
          <p>{$lang['copy_function']}:</p>
          <p>
            <select name="copy">
              <option value="1">copy()</option>
              <option value="2"{($settings['copy']==2?' selected="selected"':'')}>cURL</option>
              <option value="3"{($settings['copy']==3?' selected="selected"':'')}>copy() alternative</option>
              <option value="4"{($settings['copy']==4?' selected="selected"':'')}>Socket</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['show_cookies_message']}:</p>
          <p>
            <select name="cookies_message">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['cookies_message'] == 1 ?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['privacy_policy_url']}:</p>
          <p><input type="text" name="privacy_policy_url" value="{$settings['privacy_policy_url']}" class="long" /></p>
        </div>
        <div class="center"><input type="submit" value="{$lang['submit']}" /></div>
      </form>
      <script type="text/javascript">
    settings.init();
      </script>
{/template}

{template files_s}
      <ul class="tab_menu" id="settings_tabs">
        <li><a href="">{$lang['files']}</a></li>
        <li><a href="">{$lang['comments']}</a></li>
        <li><a href="">{$lang['cups']}</a></li>
        <li><a href="">{$lang['submit_file']}</a></li>
        <li><a href="">{$lang['categories']}</a></li>
        <li><a href="">{$lang['feed_downloader']}</a></li>
      </ul>
      <div>
        <div>
          <form id="files_settings">
            <div class="line">
              <p>{$lang['files_directory']}:</p>
              <p><input type="text" name="filesdir" value="{$settings['filesdir']}" /></p>
            </div>
            <div class="line">
              <p>{$lang['files_page']}:</p>
              <p><input type="text" name="browse_per_page" class="small" value="{$settings['browse_per_page']}" /></p>
            </div>
            <div class="line">
              <p>{$lang['files_index']}:</p>
              <p><input type="text" name="max_files_index" class="small" value="{$settings['max_files_index']}" /></p>
            </div>
            <div class="line">
              <p>{$lang['image_dimensions']}:</p>
              <p>
                <input type="text" name="image_width" class="small" value="{$settings['image_width']}" /> x
                <input type="text" name="image_height" class="small" value="{$settings['image_height']}" />
              </p>
            </div>
            <div class="line">
              <p>{$lang['max_file_dimensions']}:</p>
              <p>
                <input type="text" name="max_file_width" class="small" value="{$settings['max_file_width']}" /> x
                <input type="text" name="max_file_height" class="small" value="{$settings['max_file_height']}" />
              </p>
            </div>
            <div class="line">
              <p>{$lang['tell_friend']}:</p>
              <p>
                <select name="tellfriend">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['tellfriend']==1?' selected="selected"':'')}>{$lang['on']}</option>
                  <option value="2"{($settings['tellfriend']==2?' selected="selected"':'')}>{$lang['members_only']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['report_broken']}:</p>
              <p>
                <select name="report_broken">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['report_broken']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['rate']}:</p>
              <p>
                <select name="rate">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['rate']==1?' selected="selected"':'')}>{$lang['on']}</option>
                  <option value="2"{($settings['rate']==2?' selected="selected"':'')}>{$lang['members_only']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['add_website']}:</p>
              <p>
                <select name="add_to_website">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['add_to_website']==1?' selected="selected"':'')}>iframe</option>
                  <option value="2"{($settings['add_to_website']==2?' selected="selected"':'')}>{$lang['link']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['related_files']}:</p>
              <p>
                <select name="related_files">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['related_files']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
                {$lang['max']} <input type="text" name="max_related_files" class="small" value="{$settings['max_related_files']}" />
              </p>
            </div>
            <div class="line">
              <p>{$lang['game_activator']}:</p>
              <p>
                <select name="game_activator">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['game_activator']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
                {$lang['add_per_day']} <input type="text" name="game_activator_games" class="small" value="{$settings['game_activator_games']}" />
              </p>
            </div>
            <div class="line">
              <p>{$lang['most_popular']}:</p>
              <p>
                <select name="most_popular_list">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['most_popular_list']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
                {$lang['max']} <input type="text" name="max_most_popular" class="small" value="{$settings['max_most_popular']}" />
              </p>
            </div>
            <div class="line">
              <p>{$lang['newest']}:</p>
              <p>
                <select name="newest_list">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['newest_list']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
                {$lang['max']}
                <input type="text" name="max_newest" class="small" value="{$settings['max_newest']}" />
              </p>
            </div>
            <div class="line">
              <p>{$lang['tag_cloud']}:</p>
              <p>
                <select name="tag_cloud">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['tag_cloud']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['champions_box']}:</p>
              <p>
                <select name="champions">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['champions']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['scroller']}:</p>
              <p>
                <select name="scroller">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['scroller']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- comments settings -->
          <form id="comments_settings">
            <div class="line">
              <p>{$lang['comments']}:</p>
              <p>
                <select name="comments">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['comments']==1?' selected="selected"':'')}>{$lang['on']}</option>
                  <option value="2"{($settings['comments']==2?' selected="selected"':'')}>{$lang['members_only']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['comments_approval']}:</p>
              <p>
                <select name="comments_approval">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['comments_approval']==1?' selected="selected"':'')}>{$lang['guests_only']}</option>
                  <option value="2"{($settings['comments_approval']==2?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['comments_page']}:</p>
              <p><input type="text" name="max_comments" class="small" value="{$settings['max_comments']}" /></p>
            </div>
            <div class="line">
              <p>{$lang['flood_time']}:</p>
              <p><input type="text" name="flood_time" class="small" value="{$settings['flood_time']}" /> {$lang['seconds']}</p>
            </div>
            <div class="line">
              <div>
                <p>{$lang['banned_ips']}:</p>
                <p class="normal">({$lang['separate_comma']})</p>
              </div>
              <p><textarea name="comments_banned_ip" class="comment">{$settings['comments_banned_ip']}</textarea></p>
            </div>
            <div class="line">
              <p>{$lang['bad_words_filter']}:</p>
              <p>
                <select name="bad_word_filter">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['bad_word_filter']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['bad_words']}:</p>
              <p><input type="text" name="bad_words" class="long" value="{$settings['bad_words']}" /> ({$lang['separate_comma']})</p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- cups settings form -->
          <form id="cups_settings">
            <div class="line">
              <p>{$lang['cups']}:</p>
              <p>
                <select name="cups">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['cups']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['create_cups']}:</p>
              <p>
                <select name="cups_create">
                  <option value="1">{$lang['everybody']}</option>
                  <option value="2"{($settings['cups_create']==2?' selected="selected"':'')}>{$lang['admin_only']}</option>
                </select>
              </p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
			<p class="txt_right"><a href="http://wiki.onarcade.com/index.php/OnArcade_2.4:_Cups" target="_blank"><img src="images/help.png" alt="" /></a></p>
          </form>
        </div>
        <div>
          <!-- Submit files settings -->
          <form id="submit_files_settings">
            <div class="line">
              <p>{$lang['submit_file']}:</p>
              <p>
                <select name="submit">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['submit']==1?' selected="selected"':'')}>{$lang['on']}</option>
                  <option value="2"{($settings['submit']==2?' selected="selected"':'')}>{$lang['members_only']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['max_file_size']}:</p>
              <p><input type="text" name="submit_file_size" class="small" value="{$settings['submit_file_size']}" /> KB</p>
            </div>
            <div class="line">
              <p>{$lang['max_image_size']}:</p>
              <p><input type="text" name="submit_image_size" class="small" value="{$settings['submit_image_size']}" /> KB</p>
            </div>
            <div class="line">
              <p>{$lang['file_types']}:</p>
              <p><input type="text" name="submit_valid_file" class="long" value="{$settings['submit_valid_file']}" /> ({$lang['separate_comma']})</p>
            </div>
            <div class="line">
              <p>{$lang['image_types']}:</p>
              <p><input type="text" name="submit_valid_image" class="long" value="{$settings['submit_valid_image']}" /> ({$lang['separate_comma']})</p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- categories settings -->
          <form id="categories_settings">
            <p>{$lang['categories_used_gp']}</p>
            <div class="line">
              <p>{$lang['category_1']}:</p>
              <p>{$txt['category_1']}</p>
            </div>
            <div class="line">
              <p>{$lang['category_2']}:</p>
              <p>{$txt['category_2']}</p>
            </div>
            <div class="line">
              <p>{$lang['category_3']}:</p>
              <p>{$txt['category_3']}</p>
            </div>
            <div class="line">
              <p>{$lang['category_4']}:</p>
              <p>{$txt['category_4']}</p>
            </div>
            <div class="line">
              <p>{$lang['category_5']}:</p>
              <p>{$txt['category_5']}</p>
            </div>
            <div class="line">
              <p>{$lang['category_6']}:</p>
              <p>{$txt['category_6']}</p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <form id="game_feed_settings">
		    <div class="line">
              <p class="wide">{$lang['feed_downloader']}:</p>
              <p>
                <select name="feed_downloader">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['feed_downloader']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p class="wide">{$lang['max_games_install']}:</p>
              <p>
                <input type="text" class="small" name="feed_downloader_max" value="{$settings['feed_downloader_max']}" />
              </p>
            </div>
            <div class="line">
              <p>{$lang['feeds']}:</p>
              <p>{$txt['feeds']}</p>
            </div>
            <div class="line">
              <p>{$lang['categories']}:</p>
              <p>{$txt['feed_categories']}</p>
            </div>
            <div class="line">
              <p>{$lang['languages']}:</p>
              <p>{$txt['feed_languages']}</p>
            </div>
            <div class="line">
              <p>{$lang['min_rating']}:</p>
              <p>
                <select name="feed_downloader_rating">
                  <option value="-1">-1</option>
                  <option value="0" {$settings['feed_downloader_rating'] == 0 ? 'selected="selected"':''}>0</option>
                  <option value="1" {$settings['feed_downloader_rating'] == 1 ? 'selected="selected"':''}>1</option>
                  <option value="2" {$settings['feed_downloader_rating'] == 2 ? 'selected="selected"':''}>2</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['keywords']}:</p>
              <p>
                <input type="text" name="feed_downloader_keywords" class="long" value="{$settings['feed_downloader_keywords']}" />
              </p>
            </div>
            <div class="line">
              <p class="wide"><label for="feed_downloader_without_ads">{$lang['only_without_ads']}:</label></p>
              <p>
                <input type="checkbox" name="feed_downloader_without_ads" id="feed_downloader_without_ads" value="1" {($settings['feed_downloader_without_ads'] == 1 ? 'checked="checked"':'')} />
              </p>
            </div>
			<div class="line">
              <p class="wide"><label for="feed_downloader_scores">{$lang['only_with_scores']}:</label></p>
              <p>
                <input type="checkbox" name="feed_downloader_scores" id="feed_downloader_scores" value="1" {($settings['feed_downloader_scores'] == 1 ? 'checked="checked"':'')} />
              </p>
            </div>
			<div class="line">
              <p class="wide"><label for="feed_downloader_mobile">{$lang['only_mobile_games']}:</label></p>
              <p>
                <input type="checkbox" name="feed_downloader_mobile" id="feed_downloader_mobile" value="1" {($settings['feed_downloader_mobile'] == 1 ? 'checked="checked"':'')} />
              </p>
            </div>
			<div class="line">
              <p>{$lang['security_key']}:</p>
              <p>
                <input type="text" name="feed_downloader_key" class="long" value="{$settings['feed_downloader_key']}" />
              </p>
            </div>
			<p class="center"><input type="submit" value="{$lang['submit']}" /></p>
			<div class="separator" style="margin-bottom: 10px;"></div>
            <p>{$lang['set_up_cron_job']}</p>
            <p>PHP CLI: <input type="text" value="{$txt['cron_cli']}" class="long" id="feed_cli" /></p>
            <p>wget: <input type="text" value="{$txt['cron_wget']}" class="long" id="feed_wget" /></p>
            <p><button id="start_from_beginning">{$lang['start_from_beginning']}</button></p>
            <p class="txt_right"><a href="http://wiki.onarcade.com/index.php/OnArcade_2.4:_Game_feed_auto_downloader" target="_blank"><img src="images/help.png" alt="" /></a></p>
		  </form>
        </div>
      </div>
      <script type="text/javascript">
	feed_downloader.init();
    settings.init();
      </script>
{/template}

{template ads_s}
      <ul class="tab_menu" id="settings_tabs">
        <li><a href="">{$lang['ads']}</a></li>
        <li><a href="">{$lang['links']}</a></li>
      </ul>
      <div>
        <div>
          <!-- ads settings -->
          <form id="ads_settings">
            <div class="line">
              <p>{$lang['header_ad']}:</p>
              <p>
                <select name="header_ad">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['header_ad']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['footer_ad']}:</p>
              <p>
                <select name="footer_ad">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['footer_ad']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['file_ad']}:</p>
              <p>
                <select name="file_ad">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['file_ad']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['before_file_ad']}:</p>
              <p>
                <select name="before_file_ad">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['before_file_ad']==1?' selected="selected"':'')}>{$lang['on']}</option>
                  <option value="2"{($settings['before_file_ad']==2?' selected="selected"':'')}>{$lang['guests_only']}</option>
                </select>
                <input type="text" name="before_file_ad_time" class="small" value="{$settings['before_file_ad_time']}" /> {$lang['seconds']}
              </p>
            </div>
            <div class="line">
              <p>{$lang['time_between_ads']}:</p>
              <p><input type="text" name="before_file_ad_between" class="small" value="{$settings['before_file_ad_between']}" /> {$lang['minutes']}</p>
            </div>
            <div class="line">
              <p>{$lang['file_sponsorship']}:</p>
              <p>
                <select name="sponsor">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['sponsor']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['sponsorship_price']}:</p>
              <p>$<input type="text" name="sponsor_price" class="small" value="{$settings['sponsor_price']}" /></p>
            </div>
            <div class="line">
              <p>{$lang['paypal_email']}:</p>
              <p><input type="text" name="paypal_email" value="{$settings['paypal_email']}" /></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
        <div>
          <!-- links settings -->
          <form id="links_settings">
            <div class="line">
              <p>{$lang['links']}:</p>
              <p>
                <select name="links">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['links']==1?' selected="selected"':'')}>{$lang['on']}</option>
                </select>
                {$lang['max']} <input type="text" name="max_links" class="small" value="{$settings['max_links']}" />
              </p>
            </div>
            <div class="line">
              <p>{$lang['plugs']}:</p>
              <p>
                <select name="plugs">
                  <option value="0">{$lang['off']}</option>
                  <option value="1"{($settings['plugs']==1?' selected="selected"':'')}>{$lang['on']}</option>
                  <option value="2"{($settings['plugs']==2?' selected="selected"':'')}>{$lang['guests_only']}</option>
                </select>
              </p>
            </div>
            <div class="line">
              <p>{$lang['max_hits_gap']}:</p>
              <p><input type="text" name="max_hits_gap" class="small" value="{$settings['max_hits_gap']}" /></p>
            </div>
            <div class="line">
              <p>{$lang['plug_time']}:</p>
              <p><input type="text" name="plug_time" class="small" value="{$settings['plug_time']}" /> {$lang['minutes']}</p>
            </div>
            <div class="line">
              <p>{$lang['plug_plays']}:</p>
              <p><input type="text" name="plug_plays" class="small" value="{$settings['plug_plays']}" /></p>
            </div>
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
      </div>
      <script type="text/javascript">
    settings.init();
      </script>
{/template}

{template forums_s}
      <form id="forums_settings">
        <div class="line">
          <p>{$lang['forums']}:</p>
          <p>
            <select name="forums">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['forums']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['news']}:</p>
          <p>
            <select name="news">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['news']==1?' selected="selected"':'')}>{$lang['on']}</option>
              <option value="2"{($settings['news']==2?' selected="selected"':'')}>{$lang['get_news_forums']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['news_number']}:</p>
          <p><input type="text" name="news_index" class="small" value="{$settings['news_index']}" /></p>
        </div>
        <div class="line">
          <p>{$lang['news_forum']}:</p>
          <p>{$txt['news_forum']}</p>
        </div>
        <div class="line">
          <p>{$lang['bad_words_filter']}:</p>
          <p>
            <select name="bad_word_filter">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['bad_word_filter']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <div>
            <p>{$lang['bad_words']}:</p>
            <p class="normal">({$lang['separate_comma']})</p>
          </div>
          <p><textarea name="bad_words" class="comment">{$settings['bad_words']}</textarea></p>
        </div>
        <div class="line">
          <p>{$lang['flood_time']}:</p>
          <p><input type="text" name="flood_time" class="small" value="{$settings['flood_time']}" /> {$lang['seconds']}</p>
        </div>
        <div style="text-align: center;"><input type="submit" name="submit_settings" value="{$lang['submit']}"{$txt['s_button']} /></div>
      </form>
      <script type="text/javascript">
    settings.init();
      </script>
{/template}

{template members_s}
      <form id="members_settings">
        <div class="line">
          <p>{$lang['member_login']}:</p>
          <p>
            <select name="memberlogin">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['memberlogin']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['email_confirmation']}:</p>
          <p>
            <select name="email_confirmation">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['email_confirmation']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['custom_profile']}:</p>
          <p>
            <select name="custom_profile">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['custom_profile']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
		<div class="line">
          <p>{$lang['profile_comments']}:</p>
          <p>
            <select name="profile_comments">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['profile_comments']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['member_per_page']}:</p>
          <p><input type="text" name="member_list_per_page" class="small" value="{$settings['member_list_per_page']}" /></p>
        </div>
        <div class="line">
          <p>{$lang['guest_credits']}:</p>
          <p>
            <select name="guestcredits">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['guestcredits']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
            {$lang['max']} <input type="text" name="maxguestplays" class="small" value="{$settings['maxguestplays']}" />
          </p>
        </div>
        <div class="line">
          <p>{$lang['failed_login_quota']}:</p>
          <p><input type="text" name="failed_login_quota" class="small" value="{$settings['failed_login_quota']}" /></p>
        </div>
        <div class="line">
          <div>
            <p>{$lang['banned_ips']}:</p>
            <p class="normal">({$lang['separate_comma']})</p>
          </div>
          <p><textarea name="banned_ip" class="comment">{$settings['banned_ip']}</textarea></p>
        </div>
        <div class="line">
          <p>{$lang['remote_avatar']}:</p>
          <p>
            <select name="remote_avatar">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['remote_avatar']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['avatar_gallery']}:</p>
          <p>
            <select name="avatar_gallery">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['avatar_gallery']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['avatar_uploading']}:</p>
          <p>
            <select name="avatar_uploading">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['avatar_uploading']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['max_avatar_dimensions']}:</p>
          <p>
            <input type="text" name="avatar_width" class="small" value="{$settings['avatar_width']}" /> x
            <input type="text" name="avatar_height" class="small" value="{$settings['avatar_height']}" />
          </p>
        </div>
        <div class="line">
          <p>{$lang['max_avatar_size']}:</p>
          <p><input type="text" name="avatar_size" class="small" value="{$settings['avatar_size']}" /> KB</p>
        </div>
        <div class="line">
          <p>{$lang['top_players_list']}:</p>
          <p>
            <select name="top_players_list">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['top_players_list']==1?' selected="selected"':'')}>{$lang['plays']}</option>
              <option value="2"{($settings['top_players_list']==2?' selected="selected"':'')}>{$lang['wins']}</option>
            </select>
            {$lang['max']} <input type="text" name="max_top_players" class="small" value="{$settings['max_top_players']}" />
          </p>
        </div>
        <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
      </form>
      <script type="text/javascript">
    settings.init();
      </script>
{/template}

{template urls_s}
      <form id="urls_settings">
        <div class="line">
          <p>{$lang['se_friendly_urls']}:</p>
          <p>
            <select name="sefriendly">
              <option value="0">{$lang['off']}</option>
              <option value="1"{($settings['sefriendly']==1?' selected="selected"':'')}>{$lang['on']}</option>
            </select>
          </p>
        </div>
        <div class="line">
          <p>{$lang['category_url']}:</p>
          <p><input type="text" name="categoryurl" value="{$settings['categoryurl']}" /></p>
        </div>
        <div class="line">
          <p>{$lang['file_url']}:</p>
          <p><input type="text" name="fileurl" value="{$settings['fileurl']}" /></p>
        </div>
        <div class="line">
          <p>{$lang['profile_url']}:</p>
          <p><input type="text" name="profileurl" value="{$settings['profileurl']}" /></p>
        </div>
        <p class="center"><input type="submit" name="submit_settings" value="{$lang['submit']}"{$txt['s_button']} /></p>
      </form>
      <script type="text/javascript">
    settings.init();
      </script>
{/template}

{template languages}
      <table id="languages">
        <thead>
          <tr>
            <td>{$lang['language']}</td>
            <td style="width:160px;">{$lang['date']}</td>
            <td style="width:100px;">{$lang['translated']}</td>
            <td style="width:20px;"></td>
            <td style="width:20px;"></td>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
      <script type="text/javascript">
    languages.data = {$txt['languages']};
    languages.init();
      </script>
{/template}

{template templates}
      <table id="templates">
        <thead>
          <tr><td class="txt_left" style="width:110px;">{$lang['templates']}</td><td></td></tr>
        </thead>
        <tbody></tbody>
      </table>
      <script type="text/javascript">
    templates.data = {$txt['templates']};
    templates.template = "{$settings['template']}";
    templates.init();
      </script>
{/template}

{template template}
      <ul class="tab_menu" id="template_files_menu">
        <li><a href="">{$lang['files']}</a></li>
        <li><a href="">{$lang['edit']}</a></li>
      </ul>
      <div>
        <div>
          <table id="template_files">
            <thead>
              <tr><td style="width:18px;"></td><td class="txt_left">{$lang['file']}</td></tr>
            </thead>
            <tbody></tbody>
          </table>
        </div>
        <div>
          <form id="template_form">
            <div class="line">
              <p>{$lang['template']}:</p>
              <p>
                <span id="file_name"></span>
                <select name="function_name" id="function_name"></select>
                <img src="images/delete.png" id="delete_function" class="click" title="{$lang['delete']}" alt="{$lang['delete']}" />
                <img src="images/plus.png" id="add_function" class="click" title="{$lang['add_template']}" alt="{$lang['add_template']}" /></p>
            </div>
            <div id="code"></div>
            <p><input type="submit" value="{$lang['submit']}" /></p>
          </form>
        </div>
      </div>
      <script type="text/javascript">
    template.data = {$txt['files']};
    template.template = "{$txt['template']}";
    template.init();
      </script>
{/template}

{template log_in}
  {show overall_header}
<body>

<div id="log_in_box">
  <a href="{$settings['siteurl']}/"><img src="http://www.onarcade.com/images/logo.gif" width="331" height="104" border="0" alt="onArcade" title="onArcade" /></a>
  <!-- onArcade 2.4 Log In-->
  <div>
  {if isset($txt['error'])}
    <p class="error">{$txt['error']}</p>
  {/if}
    <form action="" method="post">
      <p>{$lang['username']}:</p>
      <p><input type="text" name="username" maxlength="25" /></p>
      <p>{$lang['password']}:</p>
      <p><input type="password" name="password" /></p>
      <p><input type="submit" value="{$lang['log_in']}" /></p>
    </form>
  </div>
  <!-- onArcade 2.4 Log In-->
  <!-- onArcade 2.4 -->
  <p>Powered by <a href="http://www.onarcade.com/" target="_blank">onArcade v{$onarcade_version}</a></p>
  <!-- onArcade 2.4 -->
</div>

</body>
</html>
{/template}

{template blank_page($title, $content)}
      {$content}
{/template}

{template redirect($redirect_url, $redirect_message)}
  {show overall_header}
<div id="redirection_box">
  <p>{$redirect_message}</p>
  <p>{$lang['if_not_redirected']}</p>
  <script type="text/javascript"> setTimeout("window.location = '{$redirect_url}';", 1000); </script>
</div>
</body>
</html>
{/template}