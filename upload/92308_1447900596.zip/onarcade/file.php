{comment}
onArcade 2.4
Copyright (c) 2006-2015 Hans Mäesalu & Eveterm OÜ, All Rights Reserved

Read http://wiki.onarcade.com/index.php/OnArcade_2.4:_Templates for more information about onArcade templates system.
<?php exit(); ?>
{/comment}

{template file}
  {if $settings['before_file_ad']}
  <div id="file_ad_box" class="content_box">
    <h2>{$lang['sponsor']}</h2>
    <div class="content">
      <div>{$ads->load_ad(4)}</div>
      <div id="ad_loader"><div></div></div>
      <p id="no_wait" class="center"><a href="" class="button">{$lang['click_wait']}</a></p>
    </div>
  </div>
  {/if}
  <div id="file_box" class="content_box">
    <h2><a href="{$settings['siteurl']}/">{$settings['sitename']}</a> &gt; <a href="{$file['cat_url']}">{$file['cat_title']}</a> &gt; {$file['title']}</h2>
    <div class="content center">
      <a href="" id="full_screen_close">{$lang['close']}</a>
	  <div id="full_screen_overlay"></div>
      <div>{$file['play_file']}</div>
      <p>
        <a href="" id="full_screen">
          <img src="{$settings['siteurl']}/images/full_screen.png" title="{$lang['full_screen']}" alt="{$lang['full_screen']}" />
        </a>
        <a href="" id="mobile_play">
          <img src="{$settings['siteurl']}/images/full_screen.png" title="{$lang['full_screen']}" alt="{$lang['full_screen']}" />
          <span>{$lang['click_here_play']}</span>
        </a>
	  </p>
    </div>
  </div>
  <div class="clear"></div>
  <div id="main_contents">
    {if $settings['sponsor'] == 1}
    <div id="sponsor">
      {$lang['sponsor']}: {$file['sponsor']}
    </div>
    {/if}
    {if $file['scores'] == 1}
    <div class="content_box">
      <h2>{$lang['scores']}</h2>
      <div class="content" id="scoreboard">
        {show scoreboard}
      </div>
      {if $session->user_status == 0}
      <p class="bold center">{$lang['log_in_save_score']}</p>
      {/if}
    </div>
    {if isset($cups) && !empty($cups)}
    <ul class="tab_menu" id="cup_tabs">
      {foreach $cups as $cup}
      <li><a href="">{$cup['name']}</a></li>
      {/foreach}
    </ul>
    <div class="content_box tab_menu_contents">
      <div class="content" id="cup_tabs_contents">
        {foreach $cups as $cup}
        <div id="cup_{$cup['id']}"></div>
        {/foreach}
      </div>
    </div>
    {/if}
  {/if}
    <ul class="tab_menu" id="file_tabs">
      <li><a href="" class="selected">{$lang['file_info']}</a></li>
      <li><a href="">{$lang['favorite']}</a></li>
      <li><a href="">{$lang['share']}</a></li>
      {if $settings['report_broken'] == 1}
      <li><a href="">{$lang['report_broken']}</a></li>
      {/if}
    </ul>
    <div class="content_box tab_menu_contents">
      <div class="content" id="file_tabs_contents">
        <div class="pos_relative">
          <p class="bold">
            {$file['title']}
            {if $session->user_group == 2}
            [<a href="{$settings['siteurl']}/admin/files.php#files_tabs/5/file/{$file['id']}">{$lang['edit']}</a>]
            {/if}
          </p>
          <p id="file_rating">{$file['rating']}</p>
          <p>{$file['description']}</p>
          <p>{$file['tags']}</p>
          <p class="file_info">{$lang['played']}: {$file['played']}</p>
          <p class="file_info">{$lang['added']}: {$file['added']}</p>
          <p class="file_info">{$lang['added_by']}: {$file['added_by']}</p>
          <div class="clear"></div>
        </div>
        <div>
          {if $session->user_status == 1}
          <button id="favorite">{($file['favourite'] ? $lang['remove_favorite'] : $lang['favorite'])}</button>
          {else}
          <p class="bold">{$lang['please_in_favorite']}</p>
          {/if}
          {if !empty($txt['like'])}
          <h4>{$lang['people_favorite']}:</h4>
            {foreach $txt['like'] as $user}
          <a href="{$user['url']}">{$user['username']}</a>
            {/foreach}
          {/if}
        </div>
        <div>
          <p>
            <a href="http://twitter.com/home?status={$file['share_message']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/twitter.png" title="Twitter" alt="Twitter" /></a>
            <a href="http://digg.com/submit?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/digg.png" title="Digg" alt="Digg" /></a>
            <a href="http://www.facebook.com/sharer.php?u={$file['share_url']}&amp;t={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/facebook.png" title="Facebook" alt="Facebook" /></a>
            <a href="http://del.icio.us/post?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/delicious.png" title="Delicious" alt="Delicious" /></a>
            <a href="http://www.stumbleupon.com/submit?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/stumbleupon.png" title="StumbleUpon" alt="StumbleUpon" /></a>
          </p>
          {if $settings['add_to_website'] != 0}
          <h4>{$lang['add_to_your_website']}:</h4>
          <p><textarea class="comment" onfocus="this.select();">{$file['add_your_website']}</textarea></p>
          {/if}
          {if $settings['tellfriend']}
          <h4>{$lang['email_friend']}:</h4>
          <form method="post" action="" id="tell_friend_form">
            <div class="line">
              <p class="left">{$lang['your_name']}</p>
              <p><input name="tell_name" type="text" value="{$session->info['username']}" maxlength="25" /></p>
            </div>
            <div class="line">
              <p class="left">{$lang['your_email_address']}</p>
              <p><input name="tell_email" type="text" value="{$session->info['email']}" maxlength="50" /></p>
            </div>
            <div class="line">
              <p class="left">{$lang['your_friends_email_address']}</p>
              <p><input name="tell_friend_email" type="text" size="30" maxlength="50" /></p>
            </div>
            {if $settings['image_verification'] == 1}
            <div>
              <p class="bold">{$lang['image_verification']}:</p>
              <div id="tell_image_verification"></div>
            </div>
            {/if}
            <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
          </form>
          {/if}
        </div>
        {if $settings['report_broken'] == 1}
        <div>
          <form method="post" action="" id="report_broken_form">
            <p>{$lang['what_wrong_file']}</p>
            <p>
              <input type="text" name="report_reason" />
              <input type="submit" value="{$lang['submit']}" />
            </p>
          </form>
        </div>
        {/if}
      </div>
    </div>
    <script type="text/javascript">
		init_file_info({$file['id']}, {$file['rating']}, {$settings['rate']}, {$settings['before_file_ad_time']});
    </script>
  {show file_ad}
    {if $settings['comments'] != 0}
    <div id="to_comments" class="content_box">
      <h2>
        {$lang['file_comments']}:
        {if $session->user_group == 2}
        [<a href="{$settings['siteurl']}/admin/files.php#files_tabs/6/comments/{$file['id']}">{$lang['edit']}</a>]
        {/if}
      </h2>
      <div class="content">
        {if $settings['comments'] == 1 || $settings['comments'] == 2 && $session->user_status == 1}
        <form action="" method="post" id="comment_form">
          <div id="bb_code"></div>
          <p><textarea name="comment" id="comment" class="comment"></textarea></p>
          {if $settings['image_verification'] == 1}
          <p id="comment_verification_field"></p>
          {/if}
          <p><input type="submit" value="{$lang['add_comment']}" /></p>
        </form>
        <script type="text/javascript">
          bb_code.attach_emoticons("bb_code", "comment");
        </script>
        {else}
        <p class="error_green">{$lang['login_to_comment']}</p>
        {/if}
        <div class="separator"></div>
        <div id="comments"></div>
      </div>
    </div>
    <script type="text/javascript">
      comments.data = {$txt['comments']};
      comments.init({$file['id']}, {$settings['max_comments']});
    </script>
    {/if}
    {if $settings['related_files']}
    <div class="content_box">
      <h2>{$lang['related_files']}:</h2>
      <div class="content">
        <div class="related_files"><!--
        {foreach $txt['related'] as $number => $related}
        --><div class="file related_file">
          <div class="icon">
            <a href="{$related['url']}">
              <img src="{$related['image']}" width="{$settings['image_width']}" height="{$settings['image_height']}" title="{$related['title']}" alt="{$related['title']}" />
              {if $related['scores'] == 1}
              <span class="scores"></span>
              {/if}
            </a>
          </div>
          <div class="desc">
            <p class="link"><a href="{$related['url']}">{$related['title']}</a></p>
            <p>{$related['description']}</p>
            <p class="played">({$lang['played_times']}: {$related['played']})</p>
          </div>
        </div><!--
        {/foreach}
         --></div>
      </div>
    </div>
    {/if}
  </div>
  {show menu}
{/template}

{template scoreboard}
        {if empty($scores['first'])}
        <p class="center">{$lang['no_scores_yet']}</p>
        {else}
        <div class="first">
          <a href="{$scores['first']['url']}">
            <img src="{$scores['first']['avatar']}" alt="" />
            {$scores['first']['username']}
          </a>
          <p>{$lang['score']}: {$scores['first']['score']}</p>
        </div>
        <div class="others">
          {foreach $scores['scores'] as $score}
          <div class="score_line{($score['me'] ? ' me':'')}">
            <p class="position">{$score['position']}</p>
            <p class="user"><a href="{$score['url']}">{$score['username']}</a></p>
            <p class="score">{$score['score']}</p>
          </div>
          {/end}
          {if $scores['all']}
          <p class="center buttons"><button id="all_scores">{$lang['all_scores']}</button></p>
          {/if}
        </div>
        <div class="clear"></div>
        {/if}
{/template}

{template frame}
  {show overall_header}
<body>

<div id="file_frame_info">
  <ul class="tab_menu" id="file_tabs">
    <li><a href="" class="selected">{$lang['file_info']}</a></li>
    <li><a href="" class="selected">{$lang['favorite']}</a></li>
    <li><a href="">{$lang['share']}</a></li>
  {if $settings['report_broken'] == 1}
    <li><a href="">{$lang['report_broken']}</a></li>
  {/if}
  </ul>
  <div class="content_box tab_menu_contents">
    <div class="pos_relative">
      <img src="{$settings['siteurl']}/images/full_screen.png" id="full_screen" title="{$lang['full_screen']}" alt="{$lang['full_screen']}" />
      <p class="bold">
          {$file['title']}
  {if $session->user_group == 2}
          [<a href="{$settings['siteurl']}/admin/files.php#files_tabs/5/file/{$file['id']}">{$lang['edit']}</a>]
  {/if}
      </p>
      <p id="file_rating">{$file['rating']}</p>
      <p>{$file['description']}</p>
      <p>{$file['tags']}</p>
      <p class="file_info">{$lang['played']}: {$file['played']}</p>
      <p class="file_info">{$lang['added']}: {$file['added']}</p>
      <p class="file_info">{$lang['added_by']}: {$file['added_by']}</p>
      <div class="clear"></div>
      <a href="{$settings['siteurl']}">{$lang['back_to_website']}</a>
    </div>
    <div>
        {if $session->user_status == 1}
      <button id="favorite">{($file['favourite'] ? $lang['remove_favorite'] : $lang['favorite'])}</button>
        {else}
      <p class="bold">{$lang['please_in_favorite']}</p>
        {/if}
        {if !empty($txt['like'])}
      <h4>{$lang['people_favorite']}:</h4>
          {foreach $txt['like'] as $user}
      <a href="{$user['url']}">{$user['username']}</a>
          {/foreach}
        {/if}
    </div>
    <div>
      <p>
        <a href="http://twitter.com/home?status={$file['share_message']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/twitter.png" title="Twitter" alt="Twitter" /></a>
        <a href="http://digg.com/submit?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/digg.png" title="Digg" alt="Digg" /></a>
        <a href="http://www.facebook.com/sharer.php?u={$file['share_url']}&amp;t={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/facebook.png" title="Facebook" alt="Facebook" /></a>
        <a href="http://del.icio.us/post?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/delicious.png" title="Delicious" alt="Delicious" /></a>
        <a href="http://www.stumbleupon.com/submit?url={$file['share_url']}&amp;title={$file['share_title']}" rel="nofollow" target="_blank"><img src="{$settings['siteurl']}/images/share/stumbleupon.png" title="StumbleUpon" alt="StumbleUpon" /></a>
      </p>
        {if $settings['add_to_website'] != 0}
      <h4>{$lang['add_to_your_website']}:</h4>
      <p><textarea class="comment" onfocus="this.select();">{$file['add_your_website']}</textarea></p>
        {/if}
  {if $settings['tellfriend']}
      <h4>{$lang['email_friend']}:</h4>
      <form method="post" action="" id="tell_friend_form">
        <div class="line">
          <p class="left">{$lang['your_name']}</p>
          <p><input name="tell_name" type="text" value="{$session->info['username']}" maxlength="25" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['your_email_address']}</p>
          <p><input name="tell_email" type="text" value="{$session->info['email']}" maxlength="50" /></p>
        </div>
        <div class="line">
          <p class="left">{$lang['your_friends_email_address']}</p>
          <p><input name="tell_friend_email" type="text" size="30" maxlength="50" /></p>
        </div>
    {if $settings['image_verification'] == 1}
        <div>
          <p class="bold">{$lang['image_verification']}:</p>
          <div id="tell_image_verification"></div>
        </div>
    {/if}
        <p class="center"><input type="submit" value="{$lang['submit']}" /></p>
      </form>
    {/if}
    </div>
  {if $settings['report_broken'] == 1}
    <div>
      <form method="post" action="" id="report_broken_form">
        <p>{$lang['what_wrong_file']}</p>
        <p>
          <input type="text" name="report_reason" />
          <input type="submit" value="{$lang['submit']}" />
        </p>
      </form>
    </div>
    {/if}
  </div>
  <script type="text/javascript">
	init_file_info({$file['id']}, {$file['rating']}, {$settings['rate']}, {$settings['before_file_ad_time']});
  </script>
</div>
<iframe src="{$file['file']}" width="100%" height="850" frameborder="0" scrolling="auto" id="file_frame"></iframe>
</body>

<script type="text/javascript">
init_frame();
</script>

</html>
{/template}

{template file_ad}
  {if $settings['file_ad'] == 1}
    <div class="ad_box_2">{$ads->load_ad(3)}</div>
  {/if}
{/template}

{template champions}
  <div id="main_contents">
    <div class="content_box">
      <h2>{$lang['all_champions']}</h2>
      <div class="content">
        <ul id="champions">
          {foreach $txt['champ'] AS $champ}
          <li><div class="pos">{$champ['pos']}</div><a href="{$champ['url']}">{$champ['username']}</a><div class="wins">{$champ['wins']} {$lang['top_wins']}</div></li>
          {/foreach}
        </ul>
        <div class="arrow_nav">
          {if $txt['previous'] > 0}
          <a href="scores.php?a=champions&amp;p={$txt['previous']}" class="previous">&lsaquo; {$lang['previous']}</a>
          {/if}
          {if $txt['next'] > 0}
          <a href="scores.php?a=champions&amp;p={$txt['next']}" class="next">{$lang['next']} &rsaquo;</a>
          {/if}
        </div>
      </div>
    </div>
  </div>
  {show menu}
{/template}

{template iframe}
{show overall_header}
<body style="margin: 0; padding: 0;">
	{if $txt['ad'] !== null}
  <div id="iframe_ad" style="width:100%;height:100%;text-align:center;">
    <div>{$txt['ad']}</div>
    <div id="ad_loader"><div></div></div>
    <p id="no_wait"><a href="">{$lang['click_wait']}</a></p>
  </div>
	{/if}
  <div id="iframe_file" style="width:100%;height:100%;">{$file['play_file']}</div>
  <script type="text/javascript"> init_iframe({$settings['before_file_ad_time']}); </script>
</body>

</html>
{/template}